MOCK_DEMO_ANALYSIS = {
    "id": 999,
    "filename": "Alex_Morgan_Software_Engineer_Resume.pdf",
    "created_at": "2026-08-08T20:45:00Z",
    "overall_score": 88,
    "projected_score": 96,
    "ats_score": 92,
    "skills_score": 85,
    "content_score": 84,
    "experience_score": 90,
    "formatting_score": 85,
    "contact_score": 95,
    "job_match_score": 86,
    "score_explanation": {
        "overall_score": 88,
        "projected_score": 96,
        "potential_gain": 8,
        "summary_text": "Your resume scored 88/100. It presents high technical density with minor deductions for missing Cloud/DevOps certifications and 1 critical skill gap (Kubernetes).",
        "top_deductions": [
            {
                "code": "MISSING_SKILL_GAP",
                "points_lost": 5,
                "title": "Missing Kubernetes Container Skill",
                "reason": "Job Description emphasizes Kubernetes, which is not listed in your resume skills.",
                "fix": "Highlight any container orchestration or Kubernetes hands-on experience."
            },
            {
                "code": "CERTIFICATION_GAP",
                "points_lost": 3,
                "title": "Missing Cloud Certification",
                "reason": "Senior roles often favor AWS or Cloud Security Certifications.",
                "fix": "Add an Industry Certifications section to validate your AWS experience."
            }
        ]
    },
    "multi_role_scores": {
        "Full Stack Engineer": {
            "score": 92,
            "icon": "fa-code",
            "matched_skills_count": 9,
            "target_skills_count": 10
        },
        "Backend Developer": {
            "score": 88,
            "icon": "fa-server",
            "matched_skills_count": 8,
            "target_skills_count": 10
        },
        "DevOps & Cloud Specialist": {
            "score": 75,
            "icon": "fa-cloud",
            "matched_skills_count": 6,
            "target_skills_count": 10
        },
        "Data & AI Engineer": {
            "score": 62,
            "icon": "fa-brain",
            "matched_skills_count": 4,
            "target_skills_count": 9
        }
    },
    "interview_prep": [
        {
            "category": "Technical Architecture",
            "focus_area": "Django API Latency",
            "question": "You mentioned reducing API response times by 45% using Django and Redis. Can you explain your caching strategy and database query optimization?",
            "answer_hint": "Explain how you utilized Redis for key-value response caching, avoided N+1 query bottlenecks using select_related/prefetch_related, and indexed foreign keys."
        },
        {
            "category": "Skill Gap Handling",
            "focus_area": "Kubernetes Onboarding",
            "question": "This position relies heavily on Kubernetes for container orchestration. How would you transfer your strong Docker expertise to Kubernetes?",
            "answer_hint": "Highlight that Docker containers form the fundamental unit of Kubernetes Pods. Detail how you understand YAML manifests, deployments, services, and your 2-week plan to master kubectl."
        },
        {
            "category": "Behavioral Leadership",
            "focus_area": "Leading Architecture Upgrades",
            "question": "How do you handle disagreement with senior team members when introducing new technologies like FastAPI or Redux?",
            "answer_hint": "Describe building a small proof-of-concept (POC) to benchmark performance, presenting data-driven arguments, and holding team knowledge sharing sessions."
        },
        {
            "category": "Technical Deep Dive",
            "focus_area": "React & TypeScript Health",
            "question": "How do you prevent memory leaks and unnecessary re-renders in large React applications using TypeScript?",
            "answer_hint": "Mention React.memo, useMemo, useCallback, proper cleanup in useEffect hooks, and strict TypeScript interface contracts."
        },
        {
            "category": "Problem Solving",
            "focus_area": "CI/CD Pipeline Failure",
            "question": "Describe how you reduced build deployment time from 35 mins to 8 mins in GitHub Actions.",
            "answer_hint": "Explain layer caching in Docker builds, parallel job matrix execution, and trimming unnecessary dependency installation steps."
        }
    ],
    "extracted_text": """
ALEX MORGAN
Senior Full Stack Engineer
Email: alex.morgan@example.com | Phone: (555) 234-5678 | San Francisco, CA
LinkedIn: linkedin.com/in/alexmorgan-dev | GitHub: github.com/alexmorgan-dev

PROFESSIONAL SUMMARY
Results-driven Senior Full Stack Software Engineer with 5+ years of experience engineering high-throughput web applications using Python, Django, JavaScript, React, and AWS. Proven track record of architecting REST APIs that reduced database latency by 40% and leading agile teams to deliver mission-critical software.

SKILLS
Programming: Python, JavaScript, TypeScript, C++, SQL, HTML5, CSS3
Frameworks & Libraries: Django, React.js, Node.js, Express, FastAPI, Redux, Tailwind CSS
Databases & Cloud: PostgreSQL, Redis, MongoDB, AWS (EC2, S3, Lambda), Docker, Nginx
DevOps & Tools: Git, GitHub Actions, CI/CD, JIRA, Postman, Linux

WORK EXPERIENCE
Senior Full Stack Engineer | TechCorp Solutions | 2022 - Present
• Spearheaded redesign of core e-commerce API platform using Django and Redis, reducing response times by 45% for 2M+ active users.
• Engineered responsive frontend web applications in React and TypeScript, improving core web vitals score from 62 to 94.
• Automated CI/CD deployment pipelines using GitHub Actions and Docker, reducing build deployment time from 35 mins to 8 mins.

Software Developer | CloudInnovate Systems | 2020 - 2022
• Developed microservices architecture using Python, FastAPI, and PostgreSQL to process over 500k daily transactions.
• Collaborated with UX designers to implement glassmorphic dashboard components using modern CSS3 animations.
• Resolved 120+ high-priority production bugs, maintaining a 99.9% service level agreement uptime.

EDUCATION
Bachelor of Science in Computer Science | University of California, Berkeley | 2016 - 2020
GPA: 3.8 / 4.0

PROJECTS
AI Resume Analyzer Platform | Django, Python, JavaScript, Chart.js
• Architected intelligent resume parser and ATS scoring engine supporting PDF/DOCX extraction and real-time visualization.
""",
    "job_description_text": """
We are seeking a Senior Full Stack Engineer proficient in Python, Django, React, PostgreSQL, Docker, AWS, and Kubernetes to lead application development for our high-growth AI SaaS platform. 
Requirements:
- 4+ years of professional software engineering experience.
- Deep expertise with Django REST Framework, Python, and modern JavaScript/React.
- Experience with containerization (Docker, Kubernetes) and AWS cloud infrastructure.
- Strong knowledge of relational databases (PostgreSQL) and caching (Redis).
""",
    "contact_info": {
        "name": "Alex Morgan",
        "email": "alex.morgan@example.com",
        "phone": "(555) 234-5678",
        "location": "San Francisco, CA",
        "linkedin": "https://linkedin.com/in/alexmorgan-dev",
        "github": "https://github.com/alexmorgan-dev",
        "portfolio": None
    },
    "extracted_skills": {
        "categories": {
            "Programming Languages": ["C++", "JavaScript", "Python", "SQL", "TypeScript"],
            "Web Technologies": ["CSS", "CSS3", "Django", "Express", "FastAPI", "HTML5", "Node.js", "React", "React.js", "Redux", "REST API", "Tailwind CSS"],
            "Databases": ["MongoDB", "PostgreSQL", "Redis", "SQL"],
            "Cloud": ["AWS", "EC2", "Lambda", "S3"],
            "DevOps & Tools": ["CI/CD", "Docker", "Git", "GitHub Actions", "JIRA", "Linux", "Nginx", "Postman"],
            "Data Science & AI": ["Data Analysis"]
        },
        "category_counts": {
            "Programming Languages": 5,
            "Web Technologies": 12,
            "Databases": 4,
            "Cloud": 4,
            "DevOps & Tools": 8,
            "Data Science & AI": 1
        },
        "all_skills": [
            "AWS", "C++", "CI/CD", "CSS", "CSS3", "Data Analysis", "Django", "Docker", "EC2", "Express",
            "FastAPI", "Git", "GitHub Actions", "HTML5", "JIRA", "JavaScript", "Lambda", "Linux",
            "MongoDB", "Nginx", "Node.js", "PostgreSQL", "Postman", "Python", "React", "React.js",
            "Redis", "Redux", "REST API", "S3", "SQL", "Tailwind CSS", "TypeScript"
        ],
        "total_count": 33
    },
    "section_analysis": {
        "sections_status": {
            "summary": True,
            "skills": True,
            "experience": True,
            "education": True,
            "projects": True,
            "certifications": False,
            "achievements": True
        },
        "present_sections": ["summary", "skills", "experience", "education", "projects", "achievements"],
        "missing_sections": ["certifications"],
        "section_count": 6
    },
    "ats_issues": [
        {
            "severity": "Good",
            "title": "Excellent ATS Structural Formatting",
            "explanation": "Standard section headings and clear reverse-chronological order detected.",
            "recommendation": "Maintain this clean formatting."
        },
        {
            "severity": "Good",
            "title": "Strong Quantified Metrics Present",
            "explanation": "Found multiple measurable achievements (e.g. 'reduced latency by 45%', '2M+ active users', '35 mins to 8 mins').",
            "recommendation": "Great job quantification of career impact."
        },
        {
            "severity": "Medium",
            "title": "Missing Industry Certifications Section",
            "explanation": "Adding recognized credentials (e.g., AWS Certified Solutions Architect) adds trust.",
            "recommendation": "Consider adding an Industry Certifications section if you possess cloud or security credentials."
        },
        {
            "severity": "Low",
            "title": "Missing Portfolio Link",
            "explanation": "While LinkedIn and GitHub are present, a direct personal portfolio link adds visual flair.",
            "recommendation": "Include a link to your custom portfolio website."
        }
    ],
    "action_verb_analysis": {
        "weak_verbs": [],
        "weak_count": 0,
        "strong_verbs": ["Architected", "Automated", "Collaborated", "Developed", "Engineered", "Spearheaded"],
        "strong_count": 6
    },
    "job_match_analysis": {
        "has_job_match": True,
        "match_score": 86,
        "matched_skills": ["AWS", "Django", "Docker", "PostgreSQL", "Python", "React", "Redis"],
        "missing_skills": ["Kubernetes"],
        "severity_matrix": [
            {
                "skill": "Kubernetes",
                "severity": "Critical",
                "badge_color": "danger",
                "learning_url": "https://kubernetes.io/docs/tutorials/kubernetes-basics/",
                "est_hours": 15
            }
        ],
        "matched_keywords": ["Python", "Django", "React", "PostgreSQL", "AWS", "Docker", "Redis", "Rest API"],
        "missing_keywords": ["Kubernetes"],
        "total_required_skills": 8,
        "recommendations": [
            "Your resume strongly aligns with this Senior Full Stack Engineer role (86% Match).",
            "Adding 'Kubernetes' to your DevOps or Skills section if you have practical container orchestration experience will increase your score to 95%+."
        ]
    },
    "summary_suggestions": [
        "Results-driven Senior Full Stack Engineer with 5+ years of experience building high-throughput web applications using Python, Django, React, and AWS. Proven track record of reducing API response times by 45% for 2M+ active users.",
        "Detail-oriented software architect specializing in Django, React, and PostgreSQL. Adept at transforming complex product goals into resilient, scalable systems with automated CI/CD pipelines.",
        "Innovative full stack engineering talent with expertise in Python cloud solutions. Passionate about leveraging cutting-edge web technologies and clean design patterns to drive application performance."
    ],
    "health_checklist": [
        {"name": "Contact Information", "status": "good"},
        {"name": "Professional Summary", "status": "good"},
        {"name": "Technical Skills", "status": "good"},
        {"name": "Work Experience", "status": "good"},
        {"name": "Education Section", "status": "good"},
        {"name": "Quantified Achievements", "status": "good"},
        {"name": "Action Verbs", "status": "good"},
        {"name": "Key Projects", "status": "good"}
    ]
}
