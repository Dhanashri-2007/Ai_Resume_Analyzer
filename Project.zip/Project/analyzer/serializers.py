from rest_framework import serializers

class ResumeUploadSerializer(serializers.Serializer):
    file = serializers.FileField(required=True)
    job_description = serializers.CharField(required=False, allow_blank=True, default="")

    def validate_file(self, value):
        valid_extensions = ['.pdf', '.docx', '.doc', '.txt']
        ext = '.' + value.name.lower().split('.')[-1]
        if ext not in valid_extensions:
            raise serializers.ValidationError("Unsupported file format. Please upload a PDF, DOCX, or TXT file.")
        
        # Max file size 10MB
        if value.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("File size exceeds maximum allowed limit of 10 MB.")
            
        return value


class JobMatchSerializer(serializers.Serializer):
    analysis_id = serializers.IntegerField(required=False, allow_null=True)
    resume_text = serializers.CharField(required=False, allow_blank=True, default="")
    job_description = serializers.CharField(required=True)


class BulletImproveSerializer(serializers.Serializer):
    bullet = serializers.CharField(required=True, max_length=1000)


class SummaryImproveSerializer(serializers.Serializer):
    analysis_id = serializers.IntegerField(required=False, allow_null=True)
    resume_text = serializers.CharField(required=False, allow_blank=True, default="")


class SimulateScoreSerializer(serializers.Serializer):
    analysis_id = serializers.IntegerField(required=False, allow_null=True)
    applied_fixes = serializers.ListField(child=serializers.CharField(), required=False, default=list)


class InterviewPrepSerializer(serializers.Serializer):
    analysis_id = serializers.IntegerField(required=False, allow_null=True)
    resume_text = serializers.CharField(required=False, allow_blank=True, default="")
    job_description = serializers.CharField(required=False, allow_blank=True, default="")
