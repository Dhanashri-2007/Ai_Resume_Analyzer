import io
from django.test import TestCase, Client
from django.urls import reverse
from rest_framework import status

from analyzer.services.extractor import extract_contact_info, parse_resume_sections
from analyzer.services.skill_engine import extract_categorized_skills
from analyzer.services.scoring_engine import calculate_resume_scores, analyze_action_verbs
from analyzer.services.job_matcher import match_resume_with_job
from analyzer.services.ai_service import generate_professional_summaries, improve_bullet_point
from analyzer.models import ResumeAnalysis


class ResumeAnalyzerBackendTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.sample_text = """
        JOHN DOE
        Software Engineer
        Email: john.doe@example.com | Phone: (123) 456-7890 | New York, NY
        LinkedIn: linkedin.com/in/johndoe-dev | GitHub: github.com/johndoe-dev

        PROFESSIONAL SUMMARY
        Experienced Full Stack Developer with 4 years of hands-on experience building web applications using Python, Django, JavaScript, React, PostgreSQL, and Docker.

        SKILLS
        Languages: Python, JavaScript, SQL, HTML, CSS
        Frameworks: Django, React, Express.js
        Databases: PostgreSQL, MongoDB, Redis
        Cloud & Tools: AWS, Docker, Git, Linux

        WORK EXPERIENCE
        Software Engineer | Tech Innovations Inc | 2021 - Present
        • Worked on backend REST APIs using Python and Django, increasing performance by 30%.
        • Developed frontend dashboards using React and Tailwind CSS for 50k active users.
        • Helped team migrate database from MySQL to PostgreSQL.

        EDUCATION
        B.S. in Computer Science | Tech University | 2017 - 2021
        """

    def test_contact_info_extraction(self):
        contact = extract_contact_info(self.sample_text)
        self.assertEqual(contact['email'], 'john.doe@example.com')
        self.assertIn('123', contact['phone'])
        self.assertIsNotNone(contact['linkedin'])
        self.assertIsNotNone(contact['github'])

    def test_section_parsing(self):
        sections = parse_resume_sections(self.sample_text)
        self.assertTrue(sections['sections_status']['summary'])
        self.assertTrue(sections['sections_status']['skills'])
        self.assertTrue(sections['sections_status']['experience'])
        self.assertTrue(sections['sections_status']['education'])

    def test_skill_extraction(self):
        skill_data = extract_categorized_skills(self.sample_text)
        skills = skill_data['all_skills']
        self.assertIn('Python', skills)
        self.assertIn('Django', skills)
        self.assertIn('React', skills)
        self.assertIn('PostgreSQL', skills)
        self.assertIn('Docker', skills)

    def test_scoring_engine(self):
        contact = extract_contact_info(self.sample_text)
        sections = parse_resume_sections(self.sample_text)
        skills = extract_categorized_skills(self.sample_text)
        
        result = calculate_resume_scores(self.sample_text, contact, sections, skills)
        scores = result['scores']
        
        self.assertGreater(scores['overall_score'], 50)
        self.assertGreater(scores['ats_score'], 60)
        self.assertIsInstance(result['ats_issues'], list)

    def test_job_description_matching(self):
        resume_skills = ['Python', 'Django', 'React', 'PostgreSQL']
        jd = "We need a Senior Engineer with Python, Django, AWS, Kubernetes, Docker, and React skills."
        
        match_result = match_resume_with_job(self.sample_text, resume_skills, jd)
        self.assertTrue(match_result['has_job_match'])
        self.assertIn('Python', match_result['matched_skills'])
        self.assertIn('Kubernetes', match_result['missing_skills'])

    def test_local_ai_fallback_service(self):
        summaries = generate_professional_summaries(self.sample_text, {'name': 'John Doe'}, ['Python', 'Django', 'React'])
        self.assertEqual(len(summaries), 3)
        
        improved_bullet = improve_bullet_point("Worked on backend development")
        self.assertIn('improved', improved_bullet)
        self.assertIn('why_better', improved_bullet)

    def test_demo_api_endpoint(self):
        response = self.client.get(reverse('api_demo'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertEqual(data['filename'], 'Alex_Morgan_Software_Engineer_Resume.pdf')

    def test_improve_bullet_api_endpoint(self):
        response = self.client.post(
            reverse('api_improve_bullet'),
            data={'bullet': 'Worked on frontend website'},
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('improved', response.json())

    def test_download_report_pdf_endpoint(self):
        response = self.client.get(reverse('api_download_report', kwargs={'pk': 999}))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response['Content-Type'], 'application/pdf')

    def test_upload_txt_resume_api(self):
        txt_file = io.BytesIO(self.sample_text.encode('utf-8'))
        txt_file.name = 'sample_resume.txt'

        response = self.client.post(
            reverse('api_analyze_resume'),
            {'file': txt_file, 'job_description': 'Senior Python Developer role'}
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.json()
        self.assertIn('overall_score', data)
        self.assertIn('id', data)
        self.assertIn('multi_role_scores', data)
        self.assertIn('interview_prep', data)

    def test_upload_pdf_resume_api(self):
        import pymupdf
        doc = pymupdf.open()
        page = doc.new_page()
        page.insert_text((50, 50), self.sample_text)
        pdf_bytes = doc.tobytes()
        doc.close()

        pdf_file = io.BytesIO(pdf_bytes)
        pdf_file.name = 'sample_resume.pdf'

        response = self.client.post(
            reverse('api_analyze_resume'),
            {'file': pdf_file, 'job_description': 'Backend Engineer'}
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.json()
        self.assertIn('overall_score', data)

    def test_upload_docx_resume_api(self):
        import docx
        doc = docx.Document()
        for line in self.sample_text.split('\n'):
            if line.strip():
                doc.add_paragraph(line.strip())
        docx_bytes = io.BytesIO()
        doc.save(docx_bytes)
        docx_bytes.seek(0)
        docx_bytes.name = 'sample_resume.docx'

        response = self.client.post(
            reverse('api_analyze_resume'),
            {'file': docx_bytes, 'job_description': 'Full Stack Developer'}
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.json()
        self.assertIn('overall_score', data)

    def test_multi_role_suitability_api(self):
        response = self.client.post(
            reverse('api_multi_role_match'),
            data={'analysis_id': 999},
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertIn('Full Stack Engineer', data)

    def test_generate_interview_prep_api(self):
        response = self.client.post(
            reverse('api_generate_interview_prep'),
            data={'analysis_id': 999},
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertIn('interview_prep', data)
        self.assertGreaterEqual(len(data['interview_prep']), 3)

    def test_simulate_score_api(self):
        response = self.client.post(
            reverse('api_simulate_score'),
            data={'analysis_id': 999, 'applied_fixes': ['QUANTIFIED_METRICS', 'WEAK_VERBS']},
            content_type='application/json'
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertIn('simulated_score', data)
        self.assertEqual(data['simulated_score'], 88 + 8)

    def test_invalid_file_format_upload(self):
        invalid_file = io.BytesIO(b"binary content")
        invalid_file.name = 'resume.exe'
        response = self.client.post(
            reverse('api_analyze_resume'),
            {'file': invalid_file}
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        data = response.json()
        self.assertIn('error', data)


from django.contrib.auth.models import User
from analyzer.models import Resume, ResumeVersion, ChatConversation, ChatMessage, ActivityLog


class UpgradeFeaturesTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Create standard user A
        self.user_a = User.objects.create_user(
            username='usera', email='usera@example.com', password='password123', first_name='User', last_name='A'
        )
        # Create standard user B
        self.user_b = User.objects.create_user(
            username='userb', email='userb@example.com', password='password123', first_name='User', last_name='B'
        )
        # Create staff admin user
        self.admin_user = User.objects.create_superuser(
            username='adminuser', email='admin@example.com', password='adminpassword123'
        )

        self.sample_text = """
        ALEX RIDER
        Software Developer
        Email: alex@example.com | Phone: 555-0199
        SKILLS: Python, Django, SQL
        EXPERIENCE: Worked on backend services for web application.
        EDUCATION: B.S. Computer Science
        """

    def test_user_registration_and_login(self):
        # Registration
        res = self.client.post(reverse('register_page'), {
            'first_name': 'New',
            'last_name': 'User',
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        })
        self.assertEqual(res.status_code, 302)
        self.assertTrue(User.objects.filter(username='newuser').exists())

        # Logout
        self.client.get(reverse('logout_action'))

        # Login
        res = self.client.post(reverse('login_page'), {
            'username': 'newuser',
            'password': 'password123'
        })
        self.assertEqual(res.status_code, 302)

    def test_authenticated_resume_upload_creates_versions(self):
        self.client.login(username='usera', password='password123')
        txt_file = io.BytesIO(self.sample_text.encode('utf-8'))
        txt_file.name = 'alex_resume.txt'

        res = self.client.post(reverse('api_analyze_resume'), {'file': txt_file})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)

        # Verify Resume and Version created
        resume = Resume.objects.filter(user=self.user_a).first()
        self.assertIsNotNone(resume)
        self.assertEqual(resume.versions.count(), 1)
        self.assertEqual(resume.versions.first().version_number, 1)

    def test_user_data_privacy_isolation(self):
        # Create resume for User A
        resume_a = Resume.objects.create(user=self.user_a, title='User A Resume', filename='a.txt')
        ResumeVersion.objects.create(resume=resume_a, version_number=1, extracted_text=self.sample_text, overall_score=70)

        # Login as User B and attempt to delete User A's resume
        self.client.login(username='userb', password='password123')
        res = self.client.post(reverse('api_delete_resume', kwargs={'pk': resume_a.id}))
        self.assertEqual(res.status_code, status.HTTP_404_NOT_FOUND)

        # Verify Resume A is untouched
        self.assertTrue(Resume.objects.filter(id=resume_a.id).exists())

    def test_ai_rewrite_creates_v2(self):
        self.client.login(username='usera', password='password123')
        resume = Resume.objects.create(user=self.user_a, title='Dev Resume', filename='dev.txt')
        ver1 = ResumeVersion.objects.create(
            resume=resume, version_number=1, extracted_text=self.sample_text,
            overall_score=68, extracted_skills={'all_skills': ['Python', 'Django']}
        )

        res = self.client.post(reverse('api_ai_rewrite_resume'), {'resume_id': resume.id}, content_type='application/json')
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        data = res.json()
        self.assertEqual(data['version_number'], 2)
        self.assertGreaterEqual(resume.versions.count(), 2)

    def test_selection_assistant_api(self):
        self.client.login(username='usera', password='password123')
        jd = "We require a Senior Python Developer with Django, Docker, AWS, and PostgreSQL experience."

        res = self.client.post(
            reverse('api_selection_assistant'),
            data={'job_description': jd, 'resume_text': self.sample_text},
            content_type='application/json'
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        data = res.json()
        self.assertIn('current_compatibility_score', data)
        self.assertIn('disclaimer', data)

    def test_ai_chat_assistant_api(self):
        self.client.login(username='usera', password='password123')

        # Send chat message
        res = self.client.post(
            reverse('api_chat_message'),
            data={'message': 'Why is my ATS score low?'},
            content_type='application/json'
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        data = res.json()
        self.assertIn('assistant_reply', data)
        conv_id = data['conversation_id']

        # List conversations
        res_list = self.client.get(reverse('api_chat_conversations'))
        self.assertEqual(res_list.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res_list.json()), 1)

        # Delete conversation
        res_del = self.client.delete(reverse('api_chat_conversation_detail', kwargs={'pk': conv_id}))
        self.assertEqual(res_del.status_code, status.HTTP_200_OK)
        self.assertEqual(ChatConversation.objects.filter(id=conv_id).count(), 0)

    def test_admin_dashboard_permissions(self):
        # Non-staff user denied
        self.client.login(username='usera', password='password123')
        res = self.client.get(reverse('admin_dashboard_page'))
        self.assertEqual(res.status_code, 302)

        # Staff user allowed
        self.client.login(username='adminuser', password='adminpassword123')
        res_admin = self.client.get(reverse('admin_dashboard_page'))
        self.assertEqual(res_admin.status_code, 200)

    def test_admin_toggle_user_active(self):
        self.client.login(username='adminuser', password='adminpassword123')

        res = self.client.post(reverse('api_admin_toggle_user', kwargs={'user_id': self.user_a.id}))
        self.assertEqual(res.status_code, status.HTTP_200_OK)

        self.user_a.refresh_from_db()
        self.assertFalse(self.user_a.is_active)


