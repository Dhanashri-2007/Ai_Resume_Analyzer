from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.db.models import Count, Q

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import (
    ResumeAnalysis, UserProfile, Resume, ResumeVersion,
    ChatConversation, ChatMessage, ActivityLog, log_activity
)
from .serializers import (
    ResumeUploadSerializer, JobMatchSerializer,
    BulletImproveSerializer, SummaryImproveSerializer
)
from .services.extractor import extract_text_from_file, extract_contact_info, parse_resume_sections
from .services.skill_engine import extract_categorized_skills
from .services.scoring_engine import calculate_resume_scores
from .services.job_matcher import match_resume_with_job, evaluate_multi_role_suitability
from .services.ai_service import (
    generate_professional_summaries, improve_bullet_point,
    generate_interview_prep_questions, rewrite_resume_content,
    generate_selection_analysis, generate_chat_response
)
from .services.report_service import generate_pdf_report

from .mock_data import MOCK_DEMO_ANALYSIS


# Helper function for user-friendly error formatting
def format_serializer_errors(errors):
    if isinstance(errors, dict):
        messages_list = []
        for k, v in errors.items():
            if isinstance(v, list):
                messages_list.append(f"{', '.join(str(i) for i in v)}")
            else:
                messages_list.append(f"{k}: {v}")
        return "; ".join(messages_list)
    return str(errors)


# ==============================================================================
# Page Rendering Views
# ==============================================================================

def landing_page_view(request):
    return render(request, 'index.html')


def upload_page_view(request):
    return render(request, 'upload.html')


def dashboard_page_view(request):
    analysis_id = request.GET.get('id')
    return render(request, 'dashboard.html', {'analysis_id': analysis_id})


def dashboard_detail_view(request, pk):
    # Verify user ownership if logged in and record exists
    if request.user.is_authenticated and pk != 999:
        analysis = ResumeAnalysis.objects.filter(pk=pk).first()
        if analysis and analysis.user and analysis.user != request.user:
            messages.error(request, "You do not have permission to view this analysis record.")
            return redirect('dashboard_page')

    return render(request, 'dashboard.html', {'analysis_id': pk})


# ------------------------------------------------------------------------------
# Authentication Views
# ------------------------------------------------------------------------------

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard_page')

    if request.method == 'POST':
        username_or_email = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()

        if not username_or_email or not password:
            messages.error(request, "Please enter both username/email and password.")
            return render(request, 'login.html')

        # Allow login by email or username
        user_obj = User.objects.filter(Q(username__iexact=username_or_email) | Q(email__iexact=username_or_email)).first()
        username = user_obj.username if user_obj else username_or_email

        user = authenticate(request, username=username, password=password)
        if user is not None:
            if not user.is_active:
                messages.error(request, "Your account has been deactivated. Please contact support.")
                return render(request, 'login.html')
            
            login(request, user)
            log_activity(user, 'LOGIN', "Logged into account")
            messages.success(request, f"Welcome back, {user.first_name or user.username}!")
            next_url = request.GET.get('next', 'dashboard_page')
            return redirect(next_url)
        else:
            messages.error(request, "Invalid username/email or password. Please check your credentials.")

    return render(request, 'login.html')


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard_page')

    if request.method == 'POST':
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        username = request.POST.get('username', '').strip()
        email = request.POST.get('email', '').strip().lower()
        password = request.POST.get('password', '').strip()
        confirm_password = request.POST.get('confirm_password', '').strip()

        # Input Validation
        if not username or not email or not password:
            messages.error(request, "All required fields must be filled.")
            return render(request, 'register.html')

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, 'register.html')

        if len(password) < 6:
            messages.error(request, "Password must be at least 6 characters long.")
            return render(request, 'register.html')

        if User.objects.filter(username__iexact=username).exists():
            messages.error(request, "Username is already taken. Please choose another.")
            return render(request, 'register.html')

        if User.objects.filter(email__iexact=email).exists():
            messages.error(request, "An account with this email address already exists.")
            return render(request, 'register.html')

        # Create User
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
            first_name=first_name,
            last_name=last_name
        )

        login(request, user)
        log_activity(user, 'REGISTER', "Created a new user account")
        messages.success(request, "Account created successfully! Welcome to ResumeAI.")
        return redirect('dashboard_page')

    return render(request, 'register.html')


def logout_view(request):
    if request.user.is_authenticated:
        log_activity(request.user, 'LOGOUT', "Logged out")
        logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('login_page')


# ------------------------------------------------------------------------------
# User Profile View
# ------------------------------------------------------------------------------

@login_required
def profile_view(request):
    user = request.user
    if request.method == 'POST':
        user.first_name = request.POST.get('first_name', user.first_name).strip()
        user.last_name = request.POST.get('last_name', user.last_name).strip()
        user.email = request.POST.get('email', user.email).strip()
        user.save()

        profile = user.profile
        profile.phone = request.POST.get('phone', profile.phone).strip()
        profile.bio = request.POST.get('bio', profile.bio).strip()
        profile.save()

        messages.success(request, "Profile updated successfully.")
        return redirect('profile_page')

    # Calculate user statistics
    resumes_count = Resume.objects.filter(user=user).count()
    rewrites_count = ResumeVersion.objects.filter(resume__user=user, version_number__gt=1).count()
    job_matches_count = ResumeAnalysis.objects.filter(user=user, job_match_score__isnull=False).count()
    chats_count = ChatConversation.objects.filter(user=user).count()
    recent_activities = ActivityLog.objects.filter(user=user)[:15]

    context = {
        'user': user,
        'resumes_count': resumes_count,
        'rewrites_count': rewrites_count,
        'job_matches_count': job_matches_count,
        'chats_count': chats_count,
        'recent_activities': recent_activities,
    }
    return render(request, 'profile.html', context)


# ------------------------------------------------------------------------------
# Resume History & Versioning Views
# ------------------------------------------------------------------------------

@login_required
def my_resumes_page_view(request):
    user_resumes = Resume.objects.filter(user=request.user).prefetch_related('versions')
    context = {
        'resumes': user_resumes
    }
    return render(request, 'resumes.html', context)


@login_required
def compare_versions_page_view(request, resume_id):
    resume = get_object_or_404(Resume, pk=resume_id, user=request.user)
    versions = resume.versions.order_by('version_number')

    v1_id = request.GET.get('v1')
    v2_id = request.GET.get('v2')

    v1 = versions.filter(pk=v1_id).first() if v1_id else (versions.first() if versions.count() >= 1 else None)
    v2 = versions.filter(pk=v2_id).first() if v2_id else (versions.last() if versions.count() >= 2 else v1)

    context = {
        'resume': resume,
        'versions': versions,
        'v1': v1,
        'v2': v2,
    }
    return render(request, 'compare.html', context)


@login_required
def selection_assistant_page_view(request):
    latest_resume = Resume.objects.filter(user=request.user).first()
    latest_version = latest_resume.latest_version if latest_resume else None
    context = {
        'latest_resume': latest_resume,
        'latest_version': latest_version
    }
    return render(request, 'selection_assistant.html', context)


@login_required
def assistant_page_view(request):
    conversations = ChatConversation.objects.filter(user=request.user).prefetch_related('messages')
    latest_resume = Resume.objects.filter(user=request.user).first()
    latest_version = latest_resume.latest_version if latest_resume else None

    context = {
        'conversations': conversations,
        'latest_version': latest_version
    }
    return render(request, 'assistant.html', context)


# ------------------------------------------------------------------------------
# Admin Views
# ------------------------------------------------------------------------------

@user_passes_test(lambda u: u.is_authenticated and u.is_staff)
def admin_dashboard_view(request):
    total_users = User.objects.count()
    active_users = User.objects.filter(is_active=True).count()
    total_resumes = Resume.objects.count()
    total_analyses = ResumeAnalysis.objects.count()
    total_rewrites = ResumeVersion.objects.filter(version_number__gt=1).count()
    total_chats = ChatConversation.objects.count()

    users_list = User.objects.annotate(
        resume_cnt=Count('resumes', distinct=True),
        chat_cnt=Count('chat_conversations', distinct=True)
    ).order_by('-date_joined')

    recent_activities = ActivityLog.objects.select_related('user').all()[:25]

    context = {
        'total_users': total_users,
        'active_users': active_users,
        'total_resumes': total_resumes,
        'total_analyses': total_analyses,
        'total_rewrites': total_rewrites,
        'total_chats': total_chats,
        'users_list': users_list,
        'recent_activities': recent_activities,
    }
    return render(request, 'admin_dashboard.html', context)


@user_passes_test(lambda u: u.is_authenticated and u.is_staff)
def admin_user_detail_view(request, user_id):
    target_user = get_object_or_404(User, pk=user_id)
    user_resumes = Resume.objects.filter(user=target_user).prefetch_related('versions')
    user_activities = ActivityLog.objects.filter(user=target_user)
    user_chats = ChatConversation.objects.filter(user=target_user)

    context = {
        'target_user': target_user,
        'resumes': user_resumes,
        'activities': user_activities,
        'chats': user_chats
    }
    return render(request, 'admin_user_detail.html', context)


# ==============================================================================
# REST API Endpoints
# ==============================================================================

class AnalyzeResumeAPIView(APIView):
    """
    POST /api/analyze-resume/
    Receives file upload and optional job description.
    Parses text, computes ATS metrics, skills, job match, and saves result.
    Attaches user ownership if logged in.
    """
    def post(self, request, *args, **kwargs):
        serializer = ResumeUploadSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({'error': format_serializer_errors(serializer.errors)}, status=status.HTTP_400_BAD_REQUEST)

        uploaded_file = serializer.validated_data['file']
        job_description = serializer.validated_data.get('job_description', '').strip()
        filename = uploaded_file.name

        try:
            # 1. Text Extraction
            raw_text = extract_text_from_file(uploaded_file, filename)

            # 2. Contact Info & Section Parsing
            contact_info = extract_contact_info(raw_text)
            section_data = parse_resume_sections(raw_text)

            # 3. Categorized Skills Extraction
            skill_data = extract_categorized_skills(raw_text)

            # 4. Resume Scoring & ATS Diagnostics
            score_results = calculate_resume_scores(raw_text, contact_info, section_data, skill_data)

            # 5. Job Description Matching (if provided)
            job_match_results = match_resume_with_job(raw_text, skill_data['all_skills'], job_description)

            # 6. Multi-Role Suitability & Interview Prep
            multi_role_scores = evaluate_multi_role_suitability(raw_text, skill_data['all_skills'])
            interview_prep = generate_interview_prep_questions(
                raw_text, skill_data['all_skills'],
                missing_skills=job_match_results.get('missing_skills', []),
                job_description=job_description
            )

            # 7. AI Professional Summary Suggestions
            summaries = generate_professional_summaries(raw_text, contact_info, skill_data['all_skills'])

            # 8. User Ownership & Resume Versioning
            user_obj = request.user if request.user.is_authenticated else None
            resume_obj = None
            version_obj = None

            if user_obj:
                clean_title = filename.rsplit('.', 1)[0].replace('_', ' ').replace('-', ' ').title()
                resume_obj = Resume.objects.create(
                    user=user_obj,
                    title=clean_title,
                    filename=filename
                )
                version_obj = ResumeVersion.objects.create(
                    resume=resume_obj,
                    version_number=1,
                    extracted_text=raw_text,
                    job_description_text=job_description,
                    overall_score=score_results['scores']['overall_score'],
                    projected_score=score_results['projected_score'],
                    ats_score=score_results['scores']['ats_score'],
                    skills_score=score_results['scores']['skills_score'],
                    content_score=score_results['scores']['content_score'],
                    experience_score=score_results['scores']['experience_score'],
                    formatting_score=score_results['scores']['formatting_score'],
                    contact_score=score_results['scores']['contact_score'],
                    job_match_score=job_match_results.get('match_score'),
                    contact_info=contact_info,
                    extracted_skills=skill_data,
                    section_analysis=section_data,
                    ats_issues=score_results['ats_issues'],
                    action_verb_analysis=score_results['action_verb_analysis'],
                    job_match_analysis=job_match_results,
                    summary_suggestions=summaries,
                    score_explanation=score_results['score_explanation'],
                    multi_role_scores=multi_role_scores,
                    interview_prep=interview_prep
                )
                log_activity(
                    user_obj, 'UPLOAD',
                    f"Uploaded and analyzed '{filename}' (Score: {score_results['scores']['overall_score']})",
                    metadata={'overall_score': score_results['scores']['overall_score']}
                )

            # 9. Persist to ResumeAnalysis DB
            analysis = ResumeAnalysis.objects.create(
                user=user_obj,
                resume=resume_obj,
                resume_version=version_obj,
                filename=filename,
                overall_score=score_results['scores']['overall_score'],
                projected_score=score_results['projected_score'],
                ats_score=score_results['scores']['ats_score'],
                skills_score=score_results['scores']['skills_score'],
                content_score=score_results['scores']['content_score'],
                experience_score=score_results['scores']['experience_score'],
                formatting_score=score_results['scores']['formatting_score'],
                contact_score=score_results['scores']['contact_score'],
                job_match_score=job_match_results.get('match_score'),
                extracted_text=raw_text,
                job_description_text=job_description,
                contact_info=contact_info,
                extracted_skills=skill_data,
                section_analysis=section_data,
                ats_issues=score_results['ats_issues'],
                action_verb_analysis=score_results['action_verb_analysis'],
                job_match_analysis=job_match_results,
                summary_suggestions=summaries,
                score_explanation=score_results['score_explanation'],
                multi_role_scores=multi_role_scores,
                interview_prep=interview_prep
            )

            response_data = {
                'id': analysis.id,
                'resume_id': resume_obj.id if resume_obj else None,
                'filename': analysis.filename,
                'created_at': analysis.created_at.isoformat(),
                'overall_score': analysis.overall_score,
                'projected_score': analysis.projected_score,
                'ats_score': analysis.ats_score,
                'skills_score': analysis.skills_score,
                'content_score': analysis.content_score,
                'experience_score': analysis.experience_score,
                'formatting_score': analysis.formatting_score,
                'contact_score': analysis.contact_score,
                'job_match_score': analysis.job_match_score,
                'extracted_text': analysis.extracted_text,
                'job_description_text': analysis.job_description_text,
                'contact_info': analysis.contact_info,
                'extracted_skills': analysis.extracted_skills,
                'section_analysis': analysis.section_analysis,
                'ats_issues': analysis.ats_issues,
                'action_verb_analysis': analysis.action_verb_analysis,
                'job_match_analysis': analysis.job_match_analysis,
                'summary_suggestions': analysis.summary_suggestions,
                'score_explanation': analysis.score_explanation,
                'multi_role_scores': analysis.multi_role_scores,
                'interview_prep': analysis.interview_prep,
                'health_checklist': score_results['health_checklist']
            }

            return Response(response_data, status=status.HTTP_201_CREATED)

        except ValueError as ve:
            return Response({'error': str(ve)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': f"Failed to analyze resume file. {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AIRewriteResumeAPIView(APIView):
    """
    POST /api/ai-rewrite-resume/
    Triggers 'AI Rewrite My Latest Resume'.
    Creates a new ResumeVersion (e.g. V2/V3) with fact-preserving AI enhancements.
    """
    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return Response({'error': 'Authentication required.'}, status=status.HTTP_401_UNAUTHORIZED)

        resume_id = request.data.get('resume_id')
        job_description = request.data.get('job_description', '').strip()

        if resume_id:
            resume = get_object_or_404(Resume, pk=resume_id, user=request.user)
        else:
            resume = Resume.objects.filter(user=request.user).first()
            if not resume:
                return Response({'error': 'No resume found. Please upload a resume first.'}, status=status.HTTP_404_NOT_FOUND)

        latest_ver = resume.latest_version
        if not latest_ver:
            return Response({'error': 'No version available for this resume.'}, status=status.HTTP_400_BAD_REQUEST)

        raw_text = latest_ver.extracted_text
        skills = latest_ver.extracted_skills.get('all_skills', [])
        jd = job_description or latest_ver.job_description_text

        # Run AI Rewrite
        rewrite_res = rewrite_resume_content(raw_text, skills, jd)
        new_text = rewrite_res['rewritten_text']

        # Re-score rewritten text
        contact_info = extract_contact_info(new_text)
        section_data = parse_resume_sections(new_text)
        skill_data = extract_categorized_skills(new_text)
        score_results = calculate_resume_scores(new_text, contact_info, section_data, skill_data)
        job_match_results = match_resume_with_job(new_text, skill_data['all_skills'], jd)
        multi_role_scores = evaluate_multi_role_suitability(new_text, skill_data['all_skills'])
        interview_prep = generate_interview_prep_questions(new_text, skill_data['all_skills'], job_match_results.get('missing_skills', []), jd)
        summaries = generate_professional_summaries(new_text, contact_info, skill_data['all_skills'])

        # Create New Version
        next_ver_num = latest_ver.version_number + 1
        new_version = ResumeVersion.objects.create(
            resume=resume,
            version_number=next_ver_num,
            extracted_text=new_text,
            job_description_text=jd,
            overall_score=score_results['scores']['overall_score'],
            projected_score=score_results['projected_score'],
            ats_score=score_results['scores']['ats_score'],
            skills_score=score_results['scores']['skills_score'],
            content_score=score_results['scores']['content_score'],
            experience_score=score_results['scores']['experience_score'],
            formatting_score=score_results['scores']['formatting_score'],
            contact_score=score_results['scores']['contact_score'],
            job_match_score=job_match_results.get('match_score'),
            contact_info=contact_info,
            extracted_skills=skill_data,
            section_analysis=section_data,
            ats_issues=score_results['ats_issues'],
            action_verb_analysis=score_results['action_verb_analysis'],
            job_match_analysis=job_match_results,
            summary_suggestions=summaries,
            score_explanation=score_results['score_explanation'],
            multi_role_scores=multi_role_scores,
            interview_prep=interview_prep,
            rewrite_notes={
                'improvements_made': rewrite_res['improvements_made'],
                'summary_of_changes': rewrite_res['summary_of_changes'],
                'prev_version': latest_ver.version_number,
                'prev_score': latest_ver.overall_score,
                'score_increase': score_results['scores']['overall_score'] - latest_ver.overall_score
            }
        )

        # Also create a ResumeAnalysis for easy dashboard viewing
        analysis = ResumeAnalysis.objects.create(
            user=request.user,
            resume=resume,
            resume_version=new_version,
            filename=f"{resume.title}_V{next_ver_num}.txt",
            overall_score=score_results['scores']['overall_score'],
            projected_score=score_results['projected_score'],
            ats_score=score_results['scores']['ats_score'],
            skills_score=score_results['scores']['skills_score'],
            content_score=score_results['scores']['content_score'],
            experience_score=score_results['scores']['experience_score'],
            formatting_score=score_results['scores']['formatting_score'],
            contact_score=score_results['scores']['contact_score'],
            job_match_score=job_match_results.get('match_score'),
            extracted_text=new_text,
            job_description_text=jd,
            contact_info=contact_info,
            extracted_skills=skill_data,
            section_analysis=section_data,
            ats_issues=score_results['ats_issues'],
            action_verb_analysis=score_results['action_verb_analysis'],
            job_match_analysis=job_match_results,
            summary_suggestions=summaries,
            score_explanation=score_results['score_explanation'],
            multi_role_scores=multi_role_scores,
            interview_prep=interview_prep
        )

        log_activity(
            request.user, 'REWRITE',
            f"Generated AI Rewrite V{next_ver_num} for '{resume.title}' (Score: {latest_ver.overall_score} ➔ {new_version.overall_score})",
            metadata={'prev_score': latest_ver.overall_score, 'new_score': new_version.overall_score}
        )

        return Response({
            'success': True,
            'analysis_id': analysis.id,
            'version_id': new_version.id,
            'version_number': new_version.version_number,
            'old_score': latest_ver.overall_score,
            'new_score': new_version.overall_score,
            'rewritten_text': new_text,
            'improvements_made': rewrite_res['improvements_made'],
            'summary_of_changes': rewrite_res['summary_of_changes']
        }, status=status.HTTP_201_CREATED)


class SelectionAssistantAPIView(APIView):
    """
    POST /api/selection-assistant/
    Runs 10-dimension Selection Chances audit against a Job Description.
    """
    def post(self, request, *args, **kwargs):
        job_description = request.data.get('job_description', '').strip()
        resume_id = request.data.get('resume_id')

        if not job_description:
            return Response({'error': 'Job description is required.'}, status=status.HTTP_400_BAD_REQUEST)

        raw_text = ""
        skills = []

        if request.user.is_authenticated:
            if resume_id:
                resume = Resume.objects.filter(pk=resume_id, user=request.user).first()
            else:
                resume = Resume.objects.filter(user=request.user).first()

            if resume and resume.latest_version:
                raw_text = resume.latest_version.extracted_text
                skills = resume.latest_version.extracted_skills.get('all_skills', [])

        if not raw_text:
            raw_text = request.data.get('resume_text', MOCK_DEMO_ANALYSIS['extracted_text'])
            skills = extract_categorized_skills(raw_text).get('all_skills', [])

        result = generate_selection_analysis(raw_text, skills, job_description)

        if request.user.is_authenticated:
            log_activity(request.user, 'SELECTION_ASSISTANT', "Ran candidate selection chances audit against target job description")

        return Response(result, status=status.HTTP_200_OK)


class ChatAPIView(APIView):
    """
    POST /api/chat/message/
    Receives user chat question and generates AI response based on candidate resume context.
    """
    def post(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return Response({'error': 'Authentication required.'}, status=status.HTTP_401_UNAUTHORIZED)

        user_message = request.data.get('message', '').strip()
        conversation_id = request.data.get('conversation_id')

        if not user_message:
            return Response({'error': 'Message text cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)

        # Get or create conversation
        if conversation_id:
            conversation = get_object_or_404(ChatConversation, pk=conversation_id, user=request.user)
        else:
            title_clean = user_message[:35] + ("..." if len(user_message) > 35 else "")
            conversation = ChatConversation.objects.create(user=request.user, title=title_clean)

        # Save user message
        ChatMessage.objects.create(conversation=conversation, sender='user', content=user_message)

        # Fetch user resume context
        resume_context = {}
        latest_resume = Resume.objects.filter(user=request.user).first()
        if latest_resume and latest_resume.latest_version:
            ver = latest_resume.latest_version
            resume_context = {
                'filename': latest_resume.filename,
                'overall_score': ver.overall_score,
                'ats_score': ver.ats_score,
                'skills': ver.extracted_skills.get('all_skills', []),
                'ats_issues': ver.ats_issues
            }

        # Build history payload
        history = list(conversation.messages.values('sender', 'content'))

        # Generate AI Assistant response
        ai_reply = generate_chat_response(history, resume_context, user_message)

        # Save assistant message
        ChatMessage.objects.create(conversation=conversation, sender='assistant', content=ai_reply)

        conversation.save()  # touch updated_at timestamp

        log_activity(request.user, 'CHAT', f"Chatted with Assistant: '{user_message[:30]}...'")

        return Response({
            'conversation_id': conversation.id,
            'title': conversation.title,
            'user_message': user_message,
            'assistant_reply': ai_reply
        }, status=status.HTTP_200_OK)


class ChatConversationsAPIView(APIView):
    """
    GET /api/chat/conversations/ -> List user chat conversations
    DELETE /api/chat/conversations/<id>/ -> Delete chat conversation
    """
    def get(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return Response({'error': 'Authentication required.'}, status=status.HTTP_401_UNAUTHORIZED)

        convs = ChatConversation.objects.filter(user=request.user)
        data = []
        for c in convs:
            msgs = list(c.messages.values('id', 'sender', 'content', 'created_at'))
            data.append({
                'id': c.id,
                'title': c.title,
                'updated_at': c.updated_at.isoformat(),
                'message_count': len(msgs),
                'messages': msgs
            })

        return Response(data, status=status.HTTP_200_OK)

    def delete(self, request, pk, *args, **kwargs):
        if not request.user.is_authenticated:
            return Response({'error': 'Authentication required.'}, status=status.HTTP_401_UNAUTHORIZED)

        conv = get_object_or_404(ChatConversation, pk=pk, user=request.user)
        conv.delete()
        log_activity(request.user, 'CHAT', "Deleted a chat conversation")
        return Response({'success': True}, status=status.HTTP_200_OK)


class DeleteResumeAPIView(APIView):
    """
    POST /api/resumes/<pk>/delete/
    Deletes user resume record and all its versions.
    """
    def post(self, request, pk, *args, **kwargs):
        if not request.user.is_authenticated:
            return Response({'error': 'Authentication required.'}, status=status.HTTP_401_UNAUTHORIZED)

        resume = get_object_or_404(Resume, pk=pk, user=request.user)
        title = resume.title
        resume.delete()
        log_activity(request.user, 'DELETE_RESUME', f"Deleted resume '{title}'")
        return Response({'success': True, 'message': f"Resume '{title}' deleted successfully."}, status=status.HTTP_200_OK)


class AdminToggleUserActiveAPIView(APIView):
    """
    POST /api/admin/toggle-user-active/<user_id>/
    Toggles is_active status of user account (Admin only).
    """
    def post(self, request, user_id, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_staff:
            return Response({'error': 'Unauthorized admin access.'}, status=status.HTTP_403_FORBIDDEN)

        target_user = get_object_or_404(User, pk=user_id)
        if target_user == request.user:
            return Response({'error': 'You cannot deactivate your own account.'}, status=status.HTTP_400_BAD_REQUEST)

        target_user.is_active = not target_user.is_active
        target_user.save()

        status_str = "activated" if target_user.is_active else "deactivated"
        log_activity(request.user, 'ADMIN_ACTION', f"Admin {status_str} user '{target_user.username}'")

        return Response({
            'success': True,
            'is_active': target_user.is_active,
            'message': f"User '{target_user.username}' has been {status_str}."
        }, status=status.HTTP_200_OK)


class AdminDeleteUserAPIView(APIView):
    """
    POST /api/admin/delete-user/<user_id>/
    Deletes user account and associated data (Admin only).
    """
    def post(self, request, user_id, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_staff:
            return Response({'error': 'Unauthorized admin access.'}, status=status.HTTP_403_FORBIDDEN)

        target_user = get_object_or_404(User, pk=user_id)
        if target_user == request.user:
            return Response({'error': 'You cannot delete your own account.'}, status=status.HTTP_400_BAD_REQUEST)

        username = target_user.username
        target_user.delete()
        log_activity(request.user, 'ADMIN_ACTION', f"Admin deleted user '{username}'")

        return Response({
            'success': True,
            'message': f"User '{username}' deleted successfully."
        }, status=status.HTTP_200_OK)


# ------------------------------------------------------------------------------
# Existing API Views Preserved
# ------------------------------------------------------------------------------

class JobMatchAPIView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = JobMatchSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({'error': format_serializer_errors(serializer.errors)}, status=status.HTTP_400_BAD_REQUEST)

        analysis_id = serializer.validated_data.get('analysis_id')
        job_description = serializer.validated_data['job_description']

        if analysis_id == 999:
            results = match_resume_with_job(MOCK_DEMO_ANALYSIS['extracted_text'], MOCK_DEMO_ANALYSIS['extracted_skills']['all_skills'], job_description)
            return Response(results, status=status.HTTP_200_OK)

        if analysis_id:
            try:
                analysis = ResumeAnalysis.objects.get(pk=analysis_id)
            except ResumeAnalysis.DoesNotExist:
                return Response({'error': f'Analysis record #{analysis_id} not found.'}, status=status.HTTP_404_NOT_FOUND)

            skills = analysis.extracted_skills.get('all_skills', [])
            raw_text = analysis.extracted_text
            results = match_resume_with_job(raw_text, skills, job_description)

            analysis.job_description_text = job_description
            analysis.job_match_score = results.get('match_score')
            analysis.job_match_analysis = results
            analysis.save()

            if request.user.is_authenticated:
                log_activity(request.user, 'MATCH', f"Matched resume against job description (Match: {results.get('match_score')}%)")

            return Response(results, status=status.HTTP_200_OK)

        resume_text = serializer.validated_data.get('resume_text', '')
        skills = extract_categorized_skills(resume_text).get('all_skills', [])
        results = match_resume_with_job(resume_text, skills, job_description)
        return Response(results, status=status.HTTP_200_OK)


class ImproveBulletAPIView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = BulletImproveSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({'error': format_serializer_errors(serializer.errors)}, status=status.HTTP_400_BAD_REQUEST)

        bullet = serializer.validated_data['bullet']
        result = improve_bullet_point(bullet)
        return Response(result, status=status.HTTP_200_OK)


class ImproveSummaryAPIView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = SummaryImproveSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({'error': format_serializer_errors(serializer.errors)}, status=status.HTTP_400_BAD_REQUEST)

        analysis_id = serializer.validated_data.get('analysis_id')
        if analysis_id == 999:
            return Response({'summaries': MOCK_DEMO_ANALYSIS['summary_suggestions']}, status=status.HTTP_200_OK)

        if analysis_id:
            try:
                analysis = ResumeAnalysis.objects.get(pk=analysis_id)
            except ResumeAnalysis.DoesNotExist:
                return Response({'error': f'Analysis record #{analysis_id} not found.'}, status=status.HTTP_404_NOT_FOUND)

            summaries = generate_professional_summaries(
                analysis.extracted_text,
                analysis.contact_info,
                analysis.extracted_skills.get('all_skills', [])
            )
            analysis.summary_suggestions = summaries
            analysis.save()
            return Response({'summaries': summaries}, status=status.HTTP_200_OK)

        resume_text = serializer.validated_data.get('resume_text', '')
        contact = extract_contact_info(resume_text)
        skills = extract_categorized_skills(resume_text).get('all_skills', [])
        summaries = generate_professional_summaries(resume_text, contact, skills)
        return Response({'summaries': summaries}, status=status.HTTP_200_OK)


class SimulateScoreAPIView(APIView):
    def post(self, request, *args, **kwargs):
        analysis_id = request.data.get('analysis_id')
        applied_fixes = request.data.get('applied_fixes', [])

        base_score = 72
        max_projected = 91

        if analysis_id == 999:
            base_score = MOCK_DEMO_ANALYSIS['overall_score']
            max_projected = MOCK_DEMO_ANALYSIS['projected_score']
        elif analysis_id:
            try:
                analysis = ResumeAnalysis.objects.get(pk=analysis_id)
                base_score = analysis.overall_score
                max_projected = analysis.projected_score or (base_score + 15)
            except ResumeAnalysis.DoesNotExist:
                pass

        boost_per_fix = 4
        boost = len(applied_fixes) * boost_per_fix
        simulated_score = min(base_score + boost, max(max_projected, base_score))

        return Response({
            'baseline_score': base_score,
            'simulated_score': simulated_score,
            'points_gained': simulated_score - base_score,
            'max_projected': max_projected
        }, status=status.HTTP_200_OK)


class GenerateInterviewPrepAPIView(APIView):
    def post(self, request, *args, **kwargs):
        analysis_id = request.data.get('analysis_id')

        if analysis_id == 999:
            return Response({'interview_prep': MOCK_DEMO_ANALYSIS['interview_prep']}, status=status.HTTP_200_OK)

        if analysis_id:
            try:
                analysis = ResumeAnalysis.objects.get(pk=analysis_id)
            except ResumeAnalysis.DoesNotExist:
                return Response({'error': f'Analysis record #{analysis_id} not found.'}, status=status.HTTP_404_NOT_FOUND)

            skills = analysis.extracted_skills.get('all_skills', [])
            missing = analysis.job_match_analysis.get('missing_skills', [])
            questions = generate_interview_prep_questions(
                analysis.extracted_text, skills, missing_skills=missing, job_description=analysis.job_description_text
            )
            analysis.interview_prep = questions
            analysis.save()
            return Response({'interview_prep': questions}, status=status.HTTP_200_OK)

        resume_text = request.data.get('resume_text', '')
        jd_text = request.data.get('job_description', '')
        skills = extract_categorized_skills(resume_text).get('all_skills', [])
        questions = generate_interview_prep_questions(resume_text, skills, job_description=jd_text)
        return Response({'interview_prep': questions}, status=status.HTTP_200_OK)


class MultiRoleMatchAPIView(APIView):
    def post(self, request, *args, **kwargs):
        analysis_id = request.data.get('analysis_id')
        if analysis_id == 999:
            return Response(MOCK_DEMO_ANALYSIS['multi_role_scores'], status=status.HTTP_200_OK)

        if analysis_id:
            try:
                analysis = ResumeAnalysis.objects.get(pk=analysis_id)
            except ResumeAnalysis.DoesNotExist:
                return Response({'error': f'Analysis record #{analysis_id} not found.'}, status=status.HTTP_404_NOT_FOUND)

            skills = analysis.extracted_skills.get('all_skills', [])
            roles = evaluate_multi_role_suitability(analysis.extracted_text, skills)
            return Response(roles, status=status.HTTP_200_OK)

        resume_text = request.data.get('resume_text', '')
        skills = extract_categorized_skills(resume_text).get('all_skills', [])
        roles = evaluate_multi_role_suitability(resume_text, skills)
        return Response(roles, status=status.HTTP_200_OK)


class DemoDataAPIView(APIView):
    def get(self, request, *args, **kwargs):
        return Response(MOCK_DEMO_ANALYSIS, status=status.HTTP_200_OK)


def download_report_view(request, pk):
    if pk == 999:
        class DemoObj:
            filename = MOCK_DEMO_ANALYSIS['filename']
            overall_score = MOCK_DEMO_ANALYSIS['overall_score']
            ats_score = MOCK_DEMO_ANALYSIS['ats_score']
            skills_score = MOCK_DEMO_ANALYSIS['skills_score']
            created_at = type('Date', (), {'strftime': lambda self, fmt: 'August 08, 2026'})()
            contact_info = MOCK_DEMO_ANALYSIS['contact_info']
            extracted_skills = MOCK_DEMO_ANALYSIS['extracted_skills']
            ats_issues = MOCK_DEMO_ANALYSIS['ats_issues']
            summary_suggestions = MOCK_DEMO_ANALYSIS['summary_suggestions']
            score_explanation = MOCK_DEMO_ANALYSIS['score_explanation']
            interview_prep = MOCK_DEMO_ANALYSIS['interview_prep']

        pdf_bytes = generate_pdf_report(DemoObj())
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="{MOCK_DEMO_ANALYSIS["filename"]}_ResumeAI_Report.pdf"'
        return response

    analysis = get_object_or_404(ResumeAnalysis, pk=pk)
    
    # Ownership Check
    if request.user.is_authenticated and analysis.user and analysis.user != request.user:
        return HttpResponse("Unauthorized access", status=403)

    pdf_bytes = generate_pdf_report(analysis)

    clean_filename = analysis.filename.split('.')[0]
    response = HttpResponse(pdf_bytes, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{clean_filename}_ResumeAI_Report.pdf"'
    return response


