from django.urls import path
from . import views

urlpatterns = [
    # Template Views
    path('', views.landing_page_view, name='landing_page'),
    path('upload/', views.upload_page_view, name='upload_page'),
    path('dashboard/', views.dashboard_page_view, name='dashboard_page'),
    path('dashboard/<int:pk>/', views.dashboard_detail_view, name='dashboard_detail'),
    
    # Auth Pages
    path('login/', views.login_view, name='login_page'),
    path('register/', views.register_view, name='register_page'),
    path('logout/', views.logout_view, name='logout_action'),
    
    # User Profile & History Pages
    path('profile/', views.profile_view, name='profile_page'),
    path('resumes/', views.my_resumes_page_view, name='my_resumes_page'),
    path('resumes/<int:resume_id>/compare/', views.compare_versions_page_view, name='compare_versions_page'),
    path('selection-assistant/', views.selection_assistant_page_view, name='selection_assistant_page'),
    path('assistant/', views.assistant_page_view, name='assistant_page'),
    
    # Admin Management Pages
    path('admin-dashboard/', views.admin_dashboard_view, name='admin_dashboard_page'),
    path('admin-dashboard/users/<int:user_id>/', views.admin_user_detail_view, name='admin_user_detail_page'),

    # REST API Endpoints
    path('api/analyze-resume/', views.AnalyzeResumeAPIView.as_view(), name='api_analyze_resume'),
    path('api/ai-rewrite-resume/', views.AIRewriteResumeAPIView.as_view(), name='api_ai_rewrite_resume'),
    path('api/selection-assistant/', views.SelectionAssistantAPIView.as_view(), name='api_selection_assistant'),
    path('api/chat/message/', views.ChatAPIView.as_view(), name='api_chat_message'),
    path('api/chat/conversations/', views.ChatConversationsAPIView.as_view(), name='api_chat_conversations'),
    path('api/chat/conversations/<int:pk>/', views.ChatConversationsAPIView.as_view(), name='api_chat_conversation_detail'),
    path('api/resumes/<int:pk>/delete/', views.DeleteResumeAPIView.as_view(), name='api_delete_resume'),


    
    # Admin API Endpoints
    path('api/admin/toggle-user-active/<int:user_id>/', views.AdminToggleUserActiveAPIView.as_view(), name='api_admin_toggle_user'),
    path('api/admin/delete-user/<int:user_id>/', views.AdminDeleteUserAPIView.as_view(), name='api_admin_delete_user'),

    # Preserved Legacy Endpoints
    path('api/job-match/', views.JobMatchAPIView.as_view(), name='api_job_match'),
    path('api/improve-bullet/', views.ImproveBulletAPIView.as_view(), name='api_improve_bullet'),
    path('api/improve-summary/', views.ImproveSummaryAPIView.as_view(), name='api_improve_summary'),
    path('api/simulate-score/', views.SimulateScoreAPIView.as_view(), name='api_simulate_score'),
    path('api/generate-interview-prep/', views.GenerateInterviewPrepAPIView.as_view(), name='api_generate_interview_prep'),
    path('api/multi-role-match/', views.MultiRoleMatchAPIView.as_view(), name='api_multi_role_match'),
    path('api/demo/', views.DemoDataAPIView.as_view(), name='api_demo'),
    path('api/download-report/<int:pk>/', views.download_report_view, name='api_download_report'),
]
