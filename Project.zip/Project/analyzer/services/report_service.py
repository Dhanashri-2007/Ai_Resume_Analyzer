import io
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

def generate_pdf_report(analysis_obj) -> bytes:
    """
    Generate a sleek PDF analysis report for a given ResumeAnalysis instance.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40
    )

    styles = getSampleStyleSheet()
    
    # Custom Palette
    PRIMARY_COLOR = colors.HexColor("#4F46E5")   # Indigo primary
    SECONDARY_COLOR = colors.HexColor("#0F172A") # Dark slate
    ACCENT_COLOR = colors.HexColor("#10B981")    # Emerald green
    TEXT_COLOR = colors.HexColor("#334155")      # Muted text
    BG_COLOR = colors.HexColor("#F8FAFC")        # Soft grey

    # Custom Paragraph Styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=22,
        leading=26,
        textColor=PRIMARY_COLOR,
        spaceAfter=4
    )
    
    subtitle_style = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontSize=10,
        leading=14,
        textColor=TEXT_COLOR,
        spaceAfter=15
    )

    h2_style = ParagraphStyle(
        'Heading2Custom',
        parent=styles['Heading2'],
        fontSize=14,
        leading=18,
        textColor=SECONDARY_COLOR,
        spaceBefore=12,
        spaceAfter=6
    )

    body_style = ParagraphStyle(
        'BodyCustom',
        parent=styles['Normal'],
        fontSize=9.5,
        leading=13.5,
        textColor=TEXT_COLOR,
        spaceAfter=6
    )

    bold_body_style = ParagraphStyle(
        'BoldBodyCustom',
        parent=body_style,
        fontName='Helvetica-Bold'
    )

    elements = []

    # Title & Header
    elements.append(Paragraph("<b>ResumeAI Diagnostic Report</b>", title_style))
    elements.append(Paragraph(f"AI-Powered Career & Resume Intelligence for: <b>{analysis_obj.filename}</b>", subtitle_style))
    elements.append(HRFlowable(width="100%", thickness=1, color=PRIMARY_COLOR, spaceAfter=15))

    # Executive Overview Scores Table
    contact = analysis_obj.contact_info or {}
    candidate_name = contact.get('name', 'Candidate')
    email = contact.get('email', 'N/A')
    date_str = analysis_obj.created_at.strftime("%B %d, %Y") if hasattr(analysis_obj.created_at, 'strftime') else 'August 2026'

    elements.append(Paragraph("1. Executive Overview & Score Projections", h2_style))
    
    score_data = [
        [Paragraph("<b>Candidate Name:</b>", body_style), Paragraph(candidate_name, body_style),
         Paragraph("<b>Current Score:</b>", body_style), Paragraph(f"<b><font color='{PRIMARY_COLOR}'>{analysis_obj.overall_score} / 100</font></b>", body_style)],
        [Paragraph("<b>Email:</b>", body_style), Paragraph(email, body_style),
         Paragraph("<b>ATS Score:</b>", body_style), Paragraph(f"{analysis_obj.ats_score} / 100", body_style)],
        [Paragraph("<b>Analysis Date:</b>", body_style), Paragraph(date_str, body_style),
         Paragraph("<b>Skills Score:</b>", body_style), Paragraph(f"{analysis_obj.skills_score} / 100", body_style)],
    ]

    score_table = Table(score_data, colWidths=[110, 160, 110, 150])
    score_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), BG_COLOR),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#CBD5E1")),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor("#E2E8F0")),
        ('PADDING', (0,0), (-1,-1), 6),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    elements.append(score_table)
    elements.append(Spacer(1, 12))

    # Explainable AI Diagnosis "Why"
    explanation = getattr(analysis_obj, 'score_explanation', {}) or {}
    if explanation.get('summary_text'):
        elements.append(Paragraph("2. Explainable AI Score Diagnostic", h2_style))
        elements.append(Paragraph(f"<b>Diagnostic Summary:</b> {explanation.get('summary_text')}", body_style))
        deductions = explanation.get('top_deductions', [])
        for d in deductions[:3]:
            elements.append(Paragraph(f"• <b>[-{d.get('points_lost', 5)} Pts] {d.get('title')}:</b> {d.get('reason')} <i>(Fix: {d.get('fix')})</i>", body_style))
        elements.append(Spacer(1, 12))

    # Extracted Technical Skills
    elements.append(Paragraph("3. Technical Skill Extraction", h2_style))
    extracted_skills_dict = analysis_obj.extracted_skills or {}
    categories = extracted_skills_dict.get('categories', {})
    
    skills_rows = []
    for cat, skills_list in categories.items():
        if skills_list:
            skills_rows.append([
                Paragraph(f"<b>{cat}</b>", body_style),
                Paragraph(", ".join(skills_list), body_style)
            ])
            
    if skills_rows:
        skills_table = Table(skills_rows, colWidths=[150, 380])
        skills_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.white),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#E2E8F0")),
            ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor("#F1F5F9")),
            ('PADDING', (0,0), (-1,-1), 6),
        ]))
        elements.append(skills_table)
    else:
        elements.append(Paragraph("No structured technical skills identified.", body_style))

    elements.append(Spacer(1, 12))

    # ATS Diagnostic Issues
    elements.append(Paragraph("4. ATS Critical Diagnostic Issues & Recommendations", h2_style))
    issues = analysis_obj.ats_issues or []
    
    if issues:
        issue_rows = [[Paragraph("<b>Severity</b>", bold_body_style), Paragraph("<b>Issue & Recommendation</b>", bold_body_style)]]
        for issue in issues[:5]:
            sev = issue.get('severity', 'Medium')
            color_map = {
                'Critical': colors.HexColor("#EF4444"),
                'High': colors.HexColor("#F97316"),
                'Medium': colors.HexColor("#EAB308"),
                'Good': colors.HexColor("#10B981")
            }
            sev_color = color_map.get(sev, colors.gray)
            
            sev_para = Paragraph(f"<b><font color='{sev_color}'>{sev.upper()}</font></b>", body_style)
            text_para = Paragraph(f"<b>{issue.get('title')}</b><br/>{issue.get('explanation')}<br/><i>Rec: {issue.get('recommendation')}</i>", body_style)
            issue_rows.append([sev_para, text_para])
            
        issue_table = Table(issue_rows, colWidths=[80, 450])
        issue_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), BG_COLOR),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#CBD5E1")),
            ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor("#E2E8F0")),
            ('PADDING', (0,0), (-1,-1), 6),
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ]))
        elements.append(issue_table)

    elements.append(Spacer(1, 12))

    # AI Interview Prep Preview
    interview_prep = getattr(analysis_obj, 'interview_prep', []) or []
    if interview_prep:
        elements.append(Paragraph("5. AI Candidate-Specific Interview Questions Preview", h2_style))
        for q in interview_prep[:3]:
            elements.append(Paragraph(f"• <b>[{q.get('category')}] {q.get('question')}</b>", body_style))
            elements.append(Paragraph(f"   <i>Hint: {q.get('answer_hint')}</i>", body_style))
            elements.append(Spacer(1, 4))

    elements.append(Spacer(1, 15))
    elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#CBD5E1"), spaceAfter=10))
    elements.append(Paragraph("<i>Report generated automatically by ResumeAI Platform. Results provided for guidance and optimization.</i>", ParagraphStyle('FooterText', parent=styles['Normal'], fontSize=8, textColor=colors.gray)))

    doc.build(elements)
    buffer.seek(0)
    return buffer.getvalue()


