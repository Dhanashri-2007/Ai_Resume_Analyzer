import re

SKILL_DICTIONARY = {
    'Programming Languages': [
        'Python', 'Java', 'JavaScript', 'TypeScript', 'C++', 'C#', 'C', 'Go', 'Golang',
        'Rust', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'R', 'MATLAB', 'Scala', 'Dart', 'Perl', 'Shell', 'Bash', 'PowerShell'
    ],
    'Web Technologies': [
        'HTML', 'HTML5', 'CSS', 'CSS3', 'React', 'React.js', 'ReactJS', 'Angular', 'Vue.js', 'Vue',
        'Django', 'Flask', 'FastAPI', 'Node.js', 'NodeJS', 'Express.js', 'Express', 'Next.js', 'Nuxt.js',
        'REST API', 'RESTful API', 'GraphQL', 'Redux', 'Tailwind CSS', 'Tailwind', 'Bootstrap',
        'Spring Boot', 'Spring', 'ASP.NET', 'jQuery', 'Sass', 'LESS', 'Webpack', 'Vite'
    ],
    'Databases': [
        'MySQL', 'PostgreSQL', 'Postgres', 'MongoDB', 'SQLite', 'Redis', 'Oracle', 'SQL Server',
        'MS SQL', 'Cassandra', 'Firebase', 'DynamoDB', 'Elasticsearch', 'MariaDB', 'Neo4j', 'Snowflake', 'SQL'
    ],
    'Cloud': [
        'AWS', 'Amazon Web Services', 'Azure', 'Microsoft Azure', 'Google Cloud', 'GCP',
        'Cloudflare', 'Heroku', 'DigitalOcean', 'Serverless', 'Lambda', 'EC2', 'S3', 'CloudFront'
    ],
    'DevOps & Tools': [
        'Docker', 'Kubernetes', 'Jenkins', 'GitHub Actions', 'Git', 'GitLab', 'Bitbucket',
        'CI/CD', 'Terraform', 'Ansible', 'Linux', 'Nginx', 'Apache', 'JIRA', 'Postman', 'Webpack',
        'Prometheus', 'Grafana', 'Maven', 'Gradle'
    ],
    'Data Science & AI': [
        'Machine Learning', 'Deep Learning', 'NLP', 'Natural Language Processing', 'Data Analysis',
        'Pandas', 'NumPy', 'TensorFlow', 'PyTorch', 'Scikit-Learn', 'OpenCV', 'LLM', 'Generative AI',
        'Computer Vision', 'PowerBI', 'Tableau', 'Spark', 'Apache Spark', 'Hadoop', 'Keras', 'SciPy', 'Matplotlib', 'Seaborn'
    ]
}

def extract_categorized_skills(text: str) -> dict:
    """
    Extract skills from raw text and organize them into standardized categories.
    Returns:
      {
        'categories': { 'Programming Languages': [...], ... },
        'all_skills': [...],
        'total_count': int
      }
    """
    extracted_by_cat = {}
    all_extracted = set()

    for category, skill_list in SKILL_DICTIONARY.items():
        cat_matches = set()
        for skill in skill_list:
            # Special regex handling for short/special characters skills
            if skill in ['C', 'R', 'Go', 'Git']:
                pattern = r'(?:\b|(?<=\s))' + re.escape(skill) + r'(?:\b|(?=\s|,|\.|\)))'
            elif '+' in skill or '#' in skill or '.' in skill:
                pattern = r'(?:^|\s|,|\()' + re.escape(skill) + r'(?:$|\s|,|\.|\))'
            else:
                pattern = r'\b' + re.escape(skill) + r'\b'

            if re.search(pattern, text, re.IGNORECASE):
                cat_matches.add(skill)
                all_extracted.add(skill)

        extracted_by_cat[category] = sorted(list(cat_matches))

    # Calculate category summary metrics
    category_counts = {cat: len(skills) for cat, skills in extracted_by_cat.items()}

    return {
        'categories': extracted_by_cat,
        'category_counts': category_counts,
        'all_skills': sorted(list(all_extracted)),
        'total_count': len(all_extracted)
    }
