from analyzer.services.skill_engine import extract_categorized_skills

SKILL_LEARNING_RESOURCES = {
    'Python': {'url': 'https://docs.python.org/3/tutorial/', 'est_hours': 10},
    'Django': {'url': 'https://docs.djangoproject.com/en/stable/intro/tutorial01/', 'est_hours': 12},
    'Docker': {'url': 'https://docs.docker.com/get-started/', 'est_hours': 8},
    'Kubernetes': {'url': 'https://kubernetes.io/docs/tutorials/kubernetes-basics/', 'est_hours': 15},
    'React': {'url': 'https://react.dev/learn', 'est_hours': 12},
    'PostgreSQL': {'url': 'https://www.postgresqltutorial.com/', 'est_hours': 8},
    'AWS': {'url': 'https://aws.amazon.com/getting-started/', 'est_hours': 20},
    'Git': {'url': 'https://git-scm.com/doc', 'est_hours': 4},
    'FastAPI': {'url': 'https://fastapi.tiangolo.com/tutorial/', 'est_hours': 6},
    'GraphQL': {'url': 'https://graphql.org/learn/', 'est_hours': 8},
    'Redis': {'url': 'https://redis.io/docs/latest/develop/get-started/', 'est_hours': 5},
    'TypeScript': {'url': 'https://www.typescriptlang.org/docs/handbook/intro.html', 'est_hours': 10},
}


def classify_skill_severities(missing_skills: list, job_description: str) -> list:
    """
    Categorize missing skills into Critical (Red), Important (Amber), and Bonus (Blue) severity levels.
    """
    jd_lower = job_description.lower()
    severity_list = []

    for skill in missing_skills:
        skill_lower = skill.lower()
        count = jd_lower.count(skill_lower)
        
        # Heuristic severity rules
        if count >= 2 or skill in ['Python', 'Docker', 'Kubernetes', 'React', 'Django', 'AWS', 'PostgreSQL', 'Java', 'C++']:
            severity = 'Critical'
            badge_color = 'danger'
        elif count == 1 or skill in ['TypeScript', 'Redis', 'FastAPI', 'Node.js', 'MongoDB', 'GraphQL', 'CI/CD']:
            severity = 'Important'
            badge_color = 'warning'
        else:
            severity = 'Bonus'
            badge_color = 'info'

        resource = SKILL_LEARNING_RESOURCES.get(skill, {
            'url': f'https://www.google.com/search?q=learn+{skill}+tutorial',
            'est_hours': 8
        })

        severity_list.append({
            'skill': skill,
            'severity': severity,
            'badge_color': badge_color,
            'learning_url': resource['url'],
            'est_hours': resource['est_hours']
        })

    # Sort Critical first, then Important, then Bonus
    order = {'Critical': 0, 'Important': 1, 'Bonus': 2}
    severity_list.sort(key=lambda x: order.get(x['severity'], 3))
    return severity_list


def evaluate_multi_role_suitability(resume_text: str, resume_skills: list) -> dict:
    """
    Benchmark profile against 4 standard industry role archetypes.
    """
    skills_set = set(s.lower() for s in resume_skills)
    text_lower = resume_text.lower()

    roles = {
        'Backend Developer': {
            'target_skills': {'python', 'django', 'fastapi', 'postgresql', 'mysql', 'sqlite', 'redis', 'rest api', 'docker', 'git'},
            'icon': 'fa-server'
        },
        'Full Stack Engineer': {
            'target_skills': {'javascript', 'typescript', 'react', 'html5', 'css3', 'python', 'django', 'rest api', 'git', 'node.js'},
            'icon': 'fa-code'
        },
        'DevOps & Cloud Specialist': {
            'target_skills': {'docker', 'kubernetes', 'aws', 'linux', 'ci/cd', 'github actions', 'jenkins', 'terraform', 'git', 'python'},
            'icon': 'fa-cloud'
        },
        'Data & AI Engineer': {
            'target_skills': {'python', 'pandas', 'numpy', 'scikit-learn', 'tensorflow', 'pytorch', 'sql', 'postgresql', 'git'},
            'icon': 'fa-brain'
        }
    }

    scores = {}
    for role_name, data in roles.items():
        targets = data['target_skills']
        matched = targets.intersection(skills_set)
        # Also check keyword mention in text
        text_matched = sum(1 for kw in targets if kw in text_lower)
        
        ratio = (len(matched) * 0.7 + (text_matched / float(len(targets))) * 0.3)
        score = int(min(max((len(matched) / float(len(targets))) * 100, 25), 98))
        
        scores[role_name] = {
            'score': score,
            'icon': data['icon'],
            'matched_skills_count': len(matched),
            'target_skills_count': len(targets)
        }

    return scores


def match_resume_with_job(resume_text: str, resume_skills: list, job_description: str) -> dict:
    """
    Compare resume content against a target job description.
    Returns match percentage, matched skills, missing skills, and tailored suggestions.
    """
    if not job_description or len(job_description.strip()) < 15:
        return {
            'has_job_match': False,
            'match_score': None,
            'matched_skills': [],
            'missing_skills': [],
            'severity_matrix': [],
            'matched_keywords': [],
            'missing_keywords': [],
            'recommendations': ["Enter a target Job Description to compare your resume and discover skill gaps."]
        }

    # Extract skills present in Job Description
    jd_skill_data = extract_categorized_skills(job_description)
    jd_skills = set(jd_skill_data.get('all_skills', []))
    
    resume_skills_set = set(resume_skills)
    
    matched_skills = sorted(list(jd_skills.intersection(resume_skills_set)))
    missing_skills = sorted(list(jd_skills.difference(resume_skills_set)))

    # Skill Severity Matrix
    severity_matrix = classify_skill_severities(missing_skills, job_description)

    # Calculate skill match score
    if jd_skills:
        skill_match_ratio = len(matched_skills) / float(len(jd_skills))
    else:
        skill_match_ratio = 0.5

    # Extract general domain keywords from JD
    stopwords = {
        'and', 'the', 'with', 'for', 'that', 'this', 'have', 'from', 'your', 'will', 'work',
        'team', 'about', 'must', 'should', 'experience', 'knowledge', 'ability', 'strong',
        'years', 'working', 'using', 'required', 'preferred', 'opportunity', 'company',
        'role', 'responsibilities', 'qualifications', 'requirements', 'looking', 'candidate'
    }
    
    jd_words = set(w.lower() for w in job_description.split() if len(w) > 3)
    jd_keywords = jd_words - stopwords
    
    resume_words = set(resume_text.lower().split())
    
    matched_keywords = sorted(list(jd_keywords.intersection(resume_words)))[:12]
    missing_keywords = sorted(list(jd_keywords.difference(resume_words)))[:12]

    if jd_keywords:
        keyword_match_ratio = len(matched_keywords) / float(len(jd_keywords))
    else:
        keyword_match_ratio = 0.5

    # Composite Match Score (0 - 100)
    match_score = int((skill_match_ratio * 70.0) + (keyword_match_ratio * 30.0))
    match_score = min(max(match_score, 10), 98)

    # Generate Tailored Recommendations
    recommendations = []
    if missing_skills:
        critical_missing = [s['skill'] for s in severity_matrix if s['severity'] == 'Critical']
        top_missing = critical_missing[:4] if critical_missing else missing_skills[:4]
        recommendations.append(
            f"Critical skills missing from your resume: {', '.join(top_missing)}. "
            "If you have hands-on experience with these tools, explicitly highlight them in your Skills or Projects section."
        )
    
    if len(matched_skills) < 3 and jd_skills:
        recommendations.append(
            "Your resume shares very few exact skill terms with the job posting. "
            "Try aligning your technical vocabulary with the exact terms used in the job description."
        )

    if match_score >= 80:
        recommendations.append("High alignment! Your profile strongly matches the key technical requirements for this position.")
    elif match_score >= 60:
        recommendations.append("Moderate alignment. Focus on adding 2-3 of the missing keywords to elevate your match score above 80%.")
    else:
        recommendations.append("Low keyword overlap. Tailor your resume summary and experience bullet points to echo the core role requirements.")

    return {
        'has_job_match': True,
        'match_score': match_score,
        'matched_skills': matched_skills,
        'missing_skills': missing_skills,
        'severity_matrix': severity_matrix,
        'matched_keywords': [k.title() for k in matched_keywords[:8]],
        'missing_keywords': [k.title() for k in missing_keywords[:8]],
        'total_required_skills': len(jd_skills),
        'recommendations': recommendations
    }
