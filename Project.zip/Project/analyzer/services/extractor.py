import re
import pymupdf
import docx

def extract_text_from_file(file_obj, filename: str) -> str:
    """
    Extract raw text from PDF, DOCX, or TXT file objects.
    """
    ext = filename.lower().split('.')[-1]
    text = ""
    
    try:
        if ext == 'pdf':
            # PyMuPDF extraction
            pdf_bytes = file_obj.read()
            doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
            for page in doc:
                page_text = page.get_text("text")
                if page_text:
                    text += page_text + "\n"
            doc.close()
            
        elif ext in ['docx', 'doc']:
            # python-docx extraction
            doc = docx.Document(file_obj)
            full_text = []
            for para in doc.paragraphs:
                if para.text.strip():
                    full_text.append(para.text.strip())
            for table in doc.tables:
                for row in table.rows:
                    row_text = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                    if row_text:
                        full_text.append(" | ".join(row_text))
            text = "\n".join(full_text)
            
        elif ext == 'txt':
            # TXT file reading with fallback encodings
            content = file_obj.read()
            if isinstance(content, bytes):
                try:
                    text = content.decode('utf-8')
                except UnicodeDecodeError:
                    text = content.decode('latin-1', errors='replace')
            else:
                text = str(content)
                
    except Exception as e:
        raise ValueError(f"Could not read content from file '{filename}'. Error: {str(e)}")

    clean_text = text.strip()
    if not clean_text or len(clean_text) < 10:
        raise ValueError("The uploaded file does not contain sufficient extractable text. Please ensure it is not scanned/empty.")
        
    return clean_text


def extract_contact_info(text: str) -> dict:
    """
    Extract contact details: Name, Email, Phone, Location, LinkedIn, GitHub, Portfolio.
    """
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    
    # 1. Email extraction
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    emails = re.findall(email_pattern, text)
    email = emails[0] if emails else None
    
    # 2. Phone extraction
    phone_pattern = r'(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\+?\d{10,13}'
    phones = re.findall(phone_pattern, text)
    phone = phones[0] if phones else None
    
    # 3. LinkedIn
    linkedin_pattern = r'(?:https?://)?(?:www\.)?linkedin\.com/in/[a-zA-Z0-9_-]+'
    linkedin_matches = re.findall(linkedin_pattern, text, re.IGNORECASE)
    linkedin = linkedin_matches[0] if linkedin_matches else None
    
    # 4. GitHub
    github_pattern = r'(?:https?://)?(?:www\.)?github\.com/[a-zA-Z0-9_-]+'
    github_matches = re.findall(github_pattern, text, re.IGNORECASE)
    github = github_matches[0] if github_matches else None
    
    # 5. Portfolio / Website
    url_pattern = r'https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?'
    urls = re.findall(url_pattern, text)
    portfolio = None
    for url in urls:
        if 'linkedin.com' not in url.lower() and 'github.com' not in url.lower():
            portfolio = url
            break
            
    # 6. Name Heuristics (Check top 5 lines)
    name = "Candidate Name"
    ignore_words = {'resume', 'curriculum', 'vitae', 'cv', 'contact', 'summary', 'profile', 'experience', 'education'}
    for line in lines[:5]:
        cleaned_line = re.sub(r'[^a-zA-Z\s]', '', line).strip()
        words = cleaned_line.split()
        if 2 <= len(words) <= 4 and not any(w.lower() in ignore_words for w in words):
            # Ensure line doesn't contain email or url
            if '@' not in line and 'http' not in line.lower() and not re.search(r'\d', line):
                name = cleaned_line.title()
                break
                
    # 7. Location Heuristics
    location = None
    location_pattern = r'([A-Z][a-zA-Z\s]+,\s*[A-Z]{2}\b|[A-Z][a-zA-Z\s]+,\s*[A-Z][a-zA-Z\s]+)'
    loc_matches = re.findall(location_pattern, text)
    if loc_matches:
        for loc in loc_matches:
            if not any(w.lower() in loc.lower() for w in ignore_words) and len(loc.strip()) < 40:
                location = loc.strip()
                break

    return {
        'name': name,
        'email': email,
        'phone': phone,
        'location': location,
        'linkedin': linkedin,
        'github': github,
        'portfolio': portfolio
    }


def parse_resume_sections(text: str) -> dict:
    """
    Detect standard resume sections and categorize their presence.
    """
    lower_text = text.lower()
    
    sections = {
        'summary': any(kw in lower_text for kw in ['summary', 'profile', 'objective', 'about me']),
        'skills': any(kw in lower_text for kw in ['skill', 'technologies', 'technical proficiency', 'core competencies']),
        'experience': any(kw in lower_text for kw in ['experience', 'employment', 'work history', 'career history', 'professional background']),
        'education': any(kw in lower_text for kw in ['education', 'academic', 'degree', 'qualification']),
        'projects': any(kw in lower_text for kw in ['project', 'key projects', 'personal projects']),
        'certifications': any(kw in lower_text for kw in ['certif', 'credentials', 'licence', 'license']),
        'achievements': any(kw in lower_text for kw in ['achievement', 'award', 'honor', 'accomplishment'])
    }
    
    present = [sec for sec, exists in sections.items() if exists]
    missing = [sec for sec, exists in sections.items() if not exists]
    
    return {
        'sections_status': sections,
        'present_sections': present,
        'missing_sections': missing,
        'section_count': len(present)
    }
