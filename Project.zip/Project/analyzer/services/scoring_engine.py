import re

WEAK_ACTION_VERBS = ['worked', 'helped', 'did', 'made', 'responsible for', 'assisted', 'handled', 'tasked with', 'involved in', 'participated']

STRONG_ACTION_VERBS = [
    'developed', 'implemented', 'designed', 'optimized', 'automated', 'engineered',
    'spearheaded', 'architected', 'transformed', 'streamlined', 'delivered', 'orchestrated',
    'pioneered', 'revamped', 'scaled', 'accelerated', 'established', 'formulated'
]

VERB_SUGGESTIONS = {
    'worked': 'Developed, Implemented, Engineered',
    'helped': 'Assisted, Spearheaded, Collaborated to deliver',
    'did': 'Executed, Completed, Managed',
    'made': 'Designed, Constructed, Built',
    'responsible for': 'Directed, Managed, Oversaw',
    'assisted': 'Supported, Coordinated, Facilitated',
    'handled': 'Resolved, Executed, Managed',
    'tasked with': 'Appointed to, Led, Managed'
}

def analyze_action_verbs(text: str) -> dict:
    """
    Detect weak and strong action verbs in the resume text.
    """
    lower_text = text.lower()
    weak_found = []
    strong_found = []

    for verb in WEAK_ACTION_VERBS:
        matches = re.findall(r'\b' + re.escape(verb) + r'\b', lower_text)
        if matches:
            weak_found.append({
                'verb': verb,
                'count': len(matches),
                'suggestion': VERB_SUGGESTIONS.get(verb, 'Developed, Implemented')
            })

    for verb in STRONG_ACTION_VERBS:
        matches = re.findall(r'\b' + re.escape(verb) + r'\b', lower_text)
        if matches:
            strong_found.append(verb.title())

    return {
        'weak_verbs': weak_found,
        'weak_count': len(weak_found),
        'strong_verbs': sorted(list(set(strong_found))),
        'strong_count': len(set(strong_found))
    }


def calculate_resume_scores(text: str, contact_info: dict, section_data: dict, skill_data: dict) -> dict:
    """
    Calculate weighted AI Resume Score (0-100) and breakdown components.
    Weights:
      - ATS Compatibility: 25%
      - Content Quality: 20%
      - Skills: 15%
      - Experience: 15%
      - Education: 10%
      - Formatting: 10%
      - Contact: 5%
    """
    # 1. Contact Score (0 - 100)
    contact_score = 0
    if contact_info.get('email'): contact_score += 30
    if contact_info.get('phone'): contact_score += 25
    if contact_info.get('linkedin'): contact_score += 25
    if contact_info.get('github') or contact_info.get('portfolio'): contact_score += 20
    contact_score = min(contact_score, 100)

    # 2. Section & Formatting Score (0 - 100)
    present_count = section_data.get('section_count', 0)
    formatting_score = min(int((present_count / 6.0) * 100), 100)

    # 3. Skills Score (0 - 100)
    total_skills = skill_data.get('total_count', 0)
    skills_score = min(int((total_skills / 15.0) * 100), 100)
    # Reward diversity of skill categories
    categories_filled = sum(1 for c, cnt in skill_data.get('category_counts', {}).items() if cnt > 0)
    skills_score = min(skills_score + (categories_filled * 5), 100)

    # 4. Experience & Content Quality Score (0 - 100)
    # Check for quantified metrics (numbers, %, $)
    metrics_matches = re.findall(r'\b(?:\d+%\b|\$\d+|\d+\+|\d+x\b|\d+\s*(?:users|clients|projects|team))', text, re.IGNORECASE)
    quantified_count = len(metrics_matches)
    
    verb_data = analyze_action_verbs(text)
    strong_verb_cnt = verb_data.get('strong_count', 0)
    
    content_score = 40
    if quantified_count >= 3:
        content_score += 30
    elif quantified_count >= 1:
        content_score += 15
        
    if strong_verb_cnt >= 5:
        content_score += 30
    elif strong_verb_cnt >= 2:
        content_score += 15

    content_score = min(content_score, 100)

    # 5. Education & Experience baseline checks
    education_score = 90 if section_data.get('sections_status', {}).get('education') else 40
    experience_score = 85 if section_data.get('sections_status', {}).get('experience') else 50

    # 6. ATS Compatibility Score (0 - 100)
    ats_score = int((formatting_score * 0.35) + (contact_score * 0.25) + (content_score * 0.25) + (skills_score * 0.15))

    # Overall Weighted Score Calculation
    overall_score = int(
        (ats_score * 0.25) +
        (content_score * 0.20) +
        (skills_score * 0.15) +
        (experience_score * 0.15) +
        (education_score * 0.10) +
        (formatting_score * 0.10) +
        (contact_score * 0.05)
    )

    overall_score = min(max(overall_score, 15), 98)

    # Generate Detailed ATS Issues & Recommendations
    ats_issues = []
    
    # Critical Issues
    if not contact_info.get('email'):
        ats_issues.append({
            'severity': 'Critical',
            'title': 'Missing Email Address',
            'explanation': 'Recruiters and ATS scanners cannot reach out without a valid email.',
            'recommendation': 'Include a clean professional email address in your header.'
        })
    if not section_data.get('sections_status', {}).get('experience'):
        ats_issues.append({
            'severity': 'Critical',
            'title': 'Missing Work Experience Section',
            'explanation': 'ATS parsers look specifically for a "Work Experience" or "Experience" heading.',
            'recommendation': 'Add a standard "Work Experience" section with reverse-chronological job entries.'
        })

    # High Severity Issues
    if quantified_count == 0:
        ats_issues.append({
            'severity': 'High',
            'title': 'Lack of Measurable Achievements',
            'explanation': 'Your resume lacks quantitative metrics (e.g. %, $, numbers, scale).',
            'recommendation': 'Incorporate measurable impact like "Improved API latency by 35%" or "Managed a team of 4".'
        })
    if verb_data.get('weak_count', 0) > 2:
        ats_issues.append({
            'severity': 'High',
            'title': 'Weak Action Verbs Detected',
            'explanation': f"Found weak words like {', '.join([w['verb'] for w in verb_data['weak_verbs'][:3]])}.",
            'recommendation': 'Replace passive language with strong action verbs like "Spearheaded", "Engineered", or "Automated".'
        })

    # Medium Severity Issues
    if not contact_info.get('linkedin'):
        ats_issues.append({
            'severity': 'Medium',
            'title': 'Missing LinkedIn Profile',
            'explanation': 'Over 85% of recruiters cross-reference LinkedIn profiles.',
            'recommendation': 'Add your customized LinkedIn URL to the header contact section.'
        })
    if 'summary' in section_data.get('missing_sections', []):
        ats_issues.append({
            'severity': 'Medium',
            'title': 'Missing Professional Summary',
            'explanation': 'A concise professional summary gives recruiters an immediate high-level value proposition.',
            'recommendation': 'Add a 2-3 sentence Professional Summary at the top of your resume.'
        })

    # Positive Factors / Good Status
    if contact_info.get('email') and contact_info.get('phone'):
        ats_issues.append({
            'severity': 'Good',
            'title': 'Complete Contact Information',
            'explanation': 'Contact details are well-structured and readily accessible to recruiters.',
            'recommendation': 'Maintain this clear formatting.'
        })
    if skills_score >= 70:
        ats_issues.append({
            'severity': 'Good',
            'title': 'Strong Categorized Technical Skills',
            'explanation': f'Identified {total_skills} technical skills across key industry categories.',
            'recommendation': 'Keep your skills section updated with your latest tools.'
        })

    # Resume Health Indicators
    health_checklist = [
        {'name': 'Contact Information', 'status': 'good' if contact_score >= 80 else 'warning'},
        {'name': 'Professional Summary', 'status': 'good' if section_data.get('sections_status', {}).get('summary') else 'warning'},
        {'name': 'Technical Skills', 'status': 'good' if skills_score >= 60 else 'warning'},
        {'name': 'Work Experience', 'status': 'good' if section_data.get('sections_status', {}).get('experience') else 'critical'},
        {'name': 'Education Section', 'status': 'good' if section_data.get('sections_status', {}).get('education') else 'warning'},
        {'name': 'Quantified Achievements', 'status': 'good' if quantified_count > 0 else 'warning'},
        {'name': 'Action Verbs', 'status': 'good' if strong_verb_cnt >= 3 else 'warning'},
        {'name': 'Key Projects', 'status': 'good' if section_data.get('sections_status', {}).get('projects') else 'good'}
    ]

    scores_dict = {
        'overall_score': overall_score,
        'ats_score': ats_score,
        'skills_score': skills_score,
        'content_score': content_score,
        'experience_score': experience_score,
        'formatting_score': formatting_score,
        'contact_score': contact_score
    }

    score_explanation = generate_score_explanation(
        scores_dict, quantified_count, verb_data, contact_info, section_data, skill_data
    )

    return {
        'scores': scores_dict,
        'ats_issues': ats_issues,
        'action_verb_analysis': verb_data,
        'health_checklist': health_checklist,
        'quantified_count': quantified_count,
        'score_explanation': score_explanation,
        'projected_score': score_explanation['projected_score']
    }


def generate_score_explanation(scores: dict, quantified_count: int, verb_data: dict, contact_info: dict, section_data: dict, skill_data: dict) -> dict:
    """
    Generate an explainable AI score breakdown explaining WHY points were lost
    and computing projected score achievable upon optimization.
    """
    overall_score = scores['overall_score']
    deductions = []
    potential_boost = 0

    if quantified_count == 0:
        deductions.append({
            'code': 'QUANTIFIED_METRICS',
            'points_lost': 12,
            'title': 'Missing Quantitative Metrics',
            'reason': 'Zero numerical impact metrics detected (%, $, team size, scale).',
            'fix': 'Add measurable metrics to experience bullets (e.g. "reduced latency by 35%").'
        })
        potential_boost += 12
    elif quantified_count < 3:
        deductions.append({
            'code': 'PARTIAL_METRICS',
            'points_lost': 6,
            'title': 'Low Metric Density',
            'reason': 'Only 1-2 quantified metrics found. High-performing resumes contain 4+.',
            'fix': 'Incorporate additional numerical outcomes into project descriptions.'
        })
        potential_boost += 6

    if verb_data.get('weak_count', 0) > 0:
        pts = min(verb_data['weak_count'] * 3, 10)
        deductions.append({
            'code': 'WEAK_VERBS',
            'points_lost': pts,
            'title': 'Passive Action Verbs',
            'reason': f"Found {verb_data['weak_count']} passive phrases like 'worked on' or 'helped'.",
            'fix': 'Replace passive verbs with high-impact words like Spearheaded, Engineered, Automated.'
        })
        potential_boost += pts

    if skill_data.get('total_count', 0) < 10:
        pts = 10
        deductions.append({
            'code': 'SKILL_DENSITY',
            'points_lost': pts,
            'title': 'Skill Section Density',
            'reason': f"Found only {skill_data.get('total_count', 0)} technical skills. Target is 12-15+ categorized skills.",
            'fix': 'Expand your skills section with modern frameworks, tools, and platforms.'
        })
        potential_boost += pts

    if not contact_info.get('linkedin'):
        deductions.append({
            'code': 'LINKEDIN_MISSING',
            'points_lost': 5,
            'title': 'Missing LinkedIn Profile',
            'reason': 'Missing LinkedIn profile link in resume header.',
            'fix': 'Add a customized LinkedIn profile URL.'
        })
        potential_boost += 5

    if 'summary' in section_data.get('missing_sections', []):
        deductions.append({
            'code': 'SUMMARY_MISSING',
            'points_lost': 6,
            'title': 'Missing Executive Summary',
            'reason': 'Missing a focused 2-3 sentence Professional Summary section.',
            'fix': 'Use AI Summary Generator to insert a tailored summary at the top.'
        })
        potential_boost += 6

    projected_score = min(overall_score + potential_boost, 96)

    # Conversational synthesis explanation
    if overall_score >= 85:
        summary_text = f"Your resume scored {overall_score}/100. It presents strong technical alignment with minimal structural deductions."
    elif overall_score >= 70:
        summary_text = f"Your score is {overall_score}/100 primarily due to missing quantitative metrics (-12 pts) and passive action verbs. Applying the suggested fixes can elevate your score to {projected_score}/100."
    else:
        summary_text = f"Your score is {overall_score}/100 because key sections and impact metrics are missing. Addressing these bottlenecks can increase your score up to {projected_score}/100 (+{projected_score - overall_score} Pts)."

    return {
        'overall_score': overall_score,
        'projected_score': projected_score,
        'potential_gain': projected_score - overall_score,
        'summary_text': summary_text,
        'top_deductions': deductions
    }
