from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone = models.CharField(max_length=50, blank=True, default="")
    bio = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Profile of {self.user.username}"


@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)
    else:
        if hasattr(instance, 'profile'):
            instance.profile.save()


class Resume(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='resumes')
    title = models.CharField(max_length=255)
    filename = models.CharField(max_length=255)
    file_path = models.CharField(max_length=500, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f"{self.title} ({self.user.username})"

    @property
    def latest_version(self):
        return self.versions.order_by('-version_number').first()


class ResumeVersion(models.Model):
    resume = models.ForeignKey(Resume, on_delete=models.CASCADE, related_name='versions')
    version_number = models.IntegerField(default=1)
    extracted_text = models.TextField(blank=True, default="")
    job_description_text = models.TextField(blank=True, default="")

    # Scores
    overall_score = models.IntegerField(default=0)
    ats_score = models.IntegerField(default=0)
    skills_score = models.IntegerField(default=0)
    content_score = models.IntegerField(default=0)
    experience_score = models.IntegerField(default=0)
    formatting_score = models.IntegerField(default=0)
    contact_score = models.IntegerField(default=0)
    job_match_score = models.IntegerField(default=0, null=True, blank=True)
    projected_score = models.IntegerField(default=0, null=True, blank=True)

    # JSON analysis payload
    contact_info = models.JSONField(default=dict, blank=True)
    extracted_skills = models.JSONField(default=dict, blank=True)
    section_analysis = models.JSONField(default=dict, blank=True)
    ats_issues = models.JSONField(default=list, blank=True)
    action_verb_analysis = models.JSONField(default=dict, blank=True)
    job_match_analysis = models.JSONField(default=dict, blank=True)
    summary_suggestions = models.JSONField(default=list, blank=True)
    score_explanation = models.JSONField(default=dict, blank=True)
    multi_role_scores = models.JSONField(default=dict, blank=True)
    interview_prep = models.JSONField(default=list, blank=True)
    rewrite_notes = models.JSONField(default=dict, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-version_number']
        unique_together = ('resume', 'version_number')

    def __str__(self):
        return f"{self.resume.title} - V{self.version_number} (Score: {self.overall_score})"


class ResumeAnalysis(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='analyses')
    resume = models.ForeignKey(Resume, on_delete=models.SET_NULL, null=True, blank=True, related_name='analyses')
    resume_version = models.ForeignKey(ResumeVersion, on_delete=models.SET_NULL, null=True, blank=True, related_name='analyses')
    
    filename = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

    # Quantitative Scores (0-100)
    overall_score = models.IntegerField(default=0)
    ats_score = models.IntegerField(default=0)
    skills_score = models.IntegerField(default=0)
    content_score = models.IntegerField(default=0)
    experience_score = models.IntegerField(default=0)
    formatting_score = models.IntegerField(default=0)
    contact_score = models.IntegerField(default=0)
    job_match_score = models.IntegerField(default=0, null=True, blank=True)
    projected_score = models.IntegerField(default=0, null=True, blank=True)

    # Raw & Parsed Data
    extracted_text = models.TextField(blank=True, default="")
    job_description_text = models.TextField(blank=True, default="")

    # Structured JSON Fields
    contact_info = models.JSONField(default=dict, blank=True)
    extracted_skills = models.JSONField(default=dict, blank=True)
    section_analysis = models.JSONField(default=dict, blank=True)
    ats_issues = models.JSONField(default=list, blank=True)
    action_verb_analysis = models.JSONField(default=dict, blank=True)
    job_match_analysis = models.JSONField(default=dict, blank=True)
    summary_suggestions = models.JSONField(default=list, blank=True)
    score_explanation = models.JSONField(default=dict, blank=True)
    multi_role_scores = models.JSONField(default=dict, blank=True)
    interview_prep = models.JSONField(default=list, blank=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Resume Analyses"

    def __str__(self):
        return f"{self.filename} - Score: {self.overall_score} ({self.created_at.strftime('%Y-%m-%d %H:%M')})"


class ChatConversation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='chat_conversations')
    title = models.CharField(max_length=255, default="ResumeAI Chat")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f"{self.title} ({self.user.username})"


class ChatMessage(models.Model):
    SENDER_CHOICES = (
        ('user', 'User'),
        ('assistant', 'Assistant'),
    )
    conversation = models.ForeignKey(ChatConversation, on_delete=models.CASCADE, related_name='messages')
    sender = models.CharField(max_length=20, choices=SENDER_CHOICES)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"{self.sender}: {self.content[:30]}"


class ActivityLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='activity_logs')
    action_type = models.CharField(max_length=50)  # e.g., 'UPLOAD', 'REWRITE', 'MATCH', 'CHAT', 'LOGIN'
    description = models.CharField(max_length=255)
    metadata = models.JSONField(default=dict, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.user.username} - {self.action_type}: {self.description}"


def log_activity(user, action_type, description, metadata=None):
    if user and user.is_authenticated:
        ActivityLog.objects.create(
            user=user,
            action_type=action_type,
            description=description,
            metadata=metadata or {}
        )

