/**
 * ResumeAI - Dashboard Controller & Chart.js Integration
 */

let charts = {};

document.addEventListener('DOMContentLoaded', () => {
    initDashboard();
});

async function initDashboard() {
    const analysisData = await loadAnalysisData();
    if (!analysisData) return;

    renderDashboardData(analysisData);
}

async function loadAnalysisData() {
    // 1. Check if demo mode requested
    const urlParams = new URLSearchParams(window.location.search);
    const isDemo = urlParams.get('demo') === 'true' || window.location.pathname.includes('/999/');

    if (isDemo) {
        try {
            const res = await fetch('/api/demo/');
            return await res.json();
        } catch (e) {
            showToast('Failed to load demo dataset', 'danger');
        }
    }

    // 2. Check session storage for recent upload
    const stored = sessionStorage.getItem('current_analysis');
    if (stored) {
        try {
            return JSON.parse(stored);
        } catch (e) {
            sessionStorage.removeItem('current_analysis');
        }
    }

    // 3. Fallback to demo mode for initial preview
    try {
        const res = await fetch('/api/demo/');
        return await res.json();
    } catch (e) {
        showToast('No analysis data found.', 'warning');
    }
}

function renderDashboardData(data) {
    // 1. Header Details
    document.getElementById('dashFilename').innerText = data.filename || 'Resume_Analysis.pdf';
    document.getElementById('dashDate').innerText = data.created_at ? new Date(data.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Today';

    // 2. Score Gauge Ring Animation
    const overallScore = data.overall_score || 0;
    const scoreCircle = document.getElementById('scoreRingFill');
    const scoreNumber = document.getElementById('scoreNumber');
    
    if (scoreCircle) {
        // Circumference 377
        const offset = 377 - (377 * (overallScore / 100));
        setTimeout(() => {
            scoreCircle.style.strokeDashoffset = offset;
        }, 100);
    }
    if (scoreNumber) {
        animateCounter(scoreNumber, overallScore, 1400);
    }

    // 3. Score Cards & Progress Bars
    updateScoreMetric('atsScore', 'atsProgress', data.ats_score || 0);
    updateScoreMetric('contentScore', 'contentProgress', data.content_score || 0);
    updateScoreMetric('skillsScore', 'skillsProgress', data.skills_score || 0);
    updateScoreMetric('experienceScore', 'experienceProgress', data.experience_score || 0);
    updateScoreMetric('formattingScore', 'formattingProgress', data.formatting_score || 0);

    // 4. Job Match Overview (If present)
    const matchBox = document.getElementById('jobMatchBox');
    const matchScoreEl = document.getElementById('jobMatchScoreVal');
    if (data.job_match_analysis && data.job_match_analysis.has_job_match) {
        if (matchBox) matchBox.style.display = 'block';
        if (matchScoreEl) animateCounter(matchScoreEl, data.job_match_analysis.match_score || 0);
    }

    // 5. Initialize Chart.js Charts
    initCharts(data);

    // 6. Extracted & Missing Skills
    renderSkillBadges(data);

    // 7. Resume Health Grid
    renderHealthChecklist(data.health_checklist || []);

    // 8. ATS Diagnostic Issues
    renderAtsIssues(data.ats_issues || []);

    // 9. Action Verbs
    renderActionVerbs(data.action_verb_analysis || {});

    // 10. AI Professional Summary Suggestions
    renderSummaries(data.summary_suggestions || []);

    // 11. Explainable AI Diagnosis & Score Simulator
    renderScoreExplanation(data);
    initScoreSimulator(data);

    // 12. Multi-Role Suitability Chart
    renderMultiRoleChart(data.multi_role_scores || {});

    // 13. Skill Gap Severity Matrix
    renderSeverityMatrix(data.job_match_analysis?.severity_matrix || []);

    // 14. AI Tailored Interview Prep
    renderInterviewPrep(data.interview_prep || []);

    // 15. PDF Report Download Listener
    const downloadBtn = document.getElementById('downloadReportBtn');
    if (downloadBtn) {
        downloadBtn.onclick = () => {
            const id = data.id || 999;
            window.location.href = `/api/download-report/${id}/`;
            showToast('Generating PDF report...', 'info');
        };
    }
}



function updateScoreMetric(numId, fillId, score) {
    const numEl = document.getElementById(numId);
    const fillEl = document.getElementById(fillId);
    if (numEl) animateCounter(numEl, score);
    if (fillEl) {
        setTimeout(() => {
            fillEl.style.width = `${score}%`;
            if (score >= 85) fillEl.className = 'progress-bar-fill success';
            else if (score >= 60) fillEl.className = 'progress-bar-fill warning';
            else fillEl.className = 'progress-bar-fill danger';
        }, 200);
    }
}

/* 💡 Explainable AI Score Diagnostic Renderer */
function renderScoreExplanation(data) {
    const baseScoreEl = document.getElementById('diagBaseScore');
    const summaryEl = document.getElementById('diagSummaryText');
    const curScoreEl = document.getElementById('simCurrentScore');
    const projScoreEl = document.getElementById('simProjectedScore');
    const gainPtsEl = document.getElementById('simGainPts');
    const deductionsContainer = document.getElementById('diagDeductionsContainer');

    const baseScore = data.overall_score || 0;
    const projScore = data.projected_score || (baseScore + 10);
    const explanation = data.score_explanation || {};

    if (baseScoreEl) baseScoreEl.innerText = baseScore;
    if (curScoreEl) curScoreEl.innerText = baseScore;
    if (projScoreEl) projScoreEl.innerText = projScore;
    if (gainPtsEl) gainPtsEl.innerText = projScore - baseScore;
    if (summaryEl) summaryEl.innerText = explanation.summary_text || 'Comprehensive breakdown of score bottlenecks and point deductions.';

    if (deductionsContainer) {
        deductionsContainer.innerHTML = '';
        const deductions = explanation.top_deductions || [];

        if (deductions.length === 0) {
            deductionsContainer.innerHTML = '<div style="color: var(--success); font-size: 0.9rem;"><i class="fa-solid fa-circle-check"></i> No critical score bottlenecks detected! Your resume scores in the elite tier.</div>';
        } else {
            deductions.forEach(d => {
                const item = document.createElement('div');
                item.style.cssText = 'background: rgba(15,23,42,0.6); border: 1px solid var(--border-color); padding: 0.75rem 1rem; border-radius: 10px; display: flex; align-items: center; justify-content: space-between; gap: 1rem;';
                item.innerHTML = `
                    <div>
                        <div style="font-weight: 700; font-size: 0.9rem; color: var(--text-primary); margin-bottom: 0.2rem;">
                            ${escapeHtml(d.title)}
                        </div>
                        <div style="font-size: 0.8rem; color: var(--text-secondary);">
                            ${escapeHtml(d.reason)}
                        </div>
                        <div style="font-size: 0.78rem; color: var(--primary); margin-top: 0.3rem;">
                            <i class="fa-solid fa-lightbulb"></i> <b>Fix:</b> ${escapeHtml(d.fix)}
                        </div>
                    </div>
                    <div style="background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); color: #EF4444; font-weight: 800; font-size: 0.9rem; padding: 0.4rem 0.75rem; border-radius: 8px; white-space: nowrap;">
                        -${d.points_lost || 5} Pts
                    </div>
                `;
                deductionsContainer.appendChild(item);
            });
        }
    }
}

/* 🎛️ Interactive Real-Time Score Simulator */
function initScoreSimulator(data) {
    const checkboxes = document.querySelectorAll('.sim-checkbox');
    if (!checkboxes.length) return;

    checkboxes.forEach(cb => {
        cb.onchange = () => updateSimulatedScore(data);
    });
}

async function updateSimulatedScore(data) {
    const checkboxes = document.querySelectorAll('.sim-checkbox:checked');
    const appliedFixes = Array.from(checkboxes).map(c => c.value);

    try {
        const res = await fetch('/api/simulate-score/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                analysis_id: data.id || 999,
                applied_fixes: appliedFixes
            })
        });
        const result = await res.json();
        if (result.simulated_score !== undefined) {
            const curScoreEl = document.getElementById('simCurrentScore');
            const scoreNumberEl = document.getElementById('scoreNumber');
            const scoreRingFill = document.getElementById('scoreRingFill');

            if (curScoreEl) animateCounter(curScoreEl, result.simulated_score, 500);
            if (scoreNumberEl) animateCounter(scoreNumberEl, result.simulated_score, 500);

            if (scoreRingFill) {
                const offset = 377 - (377 * (result.simulated_score / 100));
                scoreRingFill.style.strokeDashoffset = offset;
            }
        }
    } catch (e) {
        // Fallback local dynamic calculation
        const base = data.overall_score || 75;
        const simulated = Math.min(100, base + (appliedFixes.length * 5));
        const curScoreEl = document.getElementById('simCurrentScore');
        if (curScoreEl) animateCounter(curScoreEl, simulated, 500);
    }
}

/* 🧭 Multi-Role Suitability Radar / Bar Renderer */
function renderMultiRoleChart(multiRoleScores) {
    const canvas = document.getElementById('multiRoleChartCanvas');
    if (!canvas) return;

    const labels = Object.keys(multiRoleScores).length ? Object.keys(multiRoleScores) : ['Full Stack', 'Backend', 'DevOps', 'Data/AI'];
    const scores = Object.values(multiRoleScores).length ? Object.values(multiRoleScores).map(r => r.score) : [92, 88, 75, 62];

    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';

    if (charts.multiRole) charts.multiRole.destroy();
    charts.multiRole = new Chart(canvas, {
        type: 'radar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Fit Score (%)',
                data: scores,
                backgroundColor: 'rgba(99, 102, 241, 0.25)',
                borderColor: '#6366f1',
                pointBackgroundColor: '#6366f1',
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                r: {
                    grid: { color: gridColor },
                    angleLines: { color: gridColor },
                    suggestedMin: 40,
                    suggestedMax: 100
                }
            }
        }
    });
}

/* 🎯 Skill Gap Severity Matrix Renderer */
function renderSeverityMatrix(matrix) {
    const container = document.getElementById('severityMatrixContainer');
    if (!container) return;
    container.innerHTML = '';

    if (!matrix || matrix.length === 0) {
        container.innerHTML = '<div style="color: var(--success); font-size: 0.9rem;"><i class="fa-solid fa-circle-check"></i> Zero skill gaps identified! Resume aligns 100% with job requirements.</div>';
        return;
    }

    matrix.forEach(item => {
        const card = document.createElement('div');
        card.style.cssText = 'background: rgba(15,23,42,0.6); border: 1px solid var(--border-color); padding: 0.85rem 1.15rem; border-radius: 12px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;';
        
        let badgeClass = 'badge-primary';
        if (item.badge_color === 'danger' || item.severity === 'Critical') badgeClass = 'badge-danger';
        if (item.badge_color === 'warning' || item.severity === 'Important') badgeClass = 'badge-warning';

        card.innerHTML = `
            <div style="display: flex; align-items: center; gap: 0.75rem;">
                <span class="badge ${badgeClass}">${escapeHtml(item.severity)}</span>
                <span style="font-weight: 700; font-size: 1rem; color: var(--text-primary);">${escapeHtml(item.skill)}</span>
            </div>
            <div style="display: flex; align-items: center; gap: 1.25rem;">
                <span style="font-size: 0.82rem; color: var(--text-secondary);"><i class="fa-regular fa-clock"></i> ~${item.est_hours || 10} Hours Learning Curve</span>
                <a href="${item.learning_url || '#'}" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-secondary" style="font-size: 0.8rem;">
                    <i class="fa-solid fa-book-open"></i> Learning Roadmap
                </a>
            </div>
        `;
        container.appendChild(card);
    });
}

/* 🎙️ AI Resume-Tailored Interview Prep Accordion Renderer */
function renderInterviewPrep(questions) {
    const container = document.getElementById('interviewQuestionsContainer');
    if (!container) return;
    container.innerHTML = '';

    if (!questions || questions.length === 0) {
        container.innerHTML = '<div class="text-muted">No interview prep questions generated yet.</div>';
        return;
    }

    questions.forEach((q, idx) => {
        const card = document.createElement('div');
        card.style.cssText = 'background: rgba(15,23,42,0.7); border: 1px solid var(--border-color); border-radius: 12px; overflow: hidden;';
        
        card.innerHTML = `
            <div style="padding: 1rem 1.25rem; cursor: pointer; display: flex; justify-content: space-between; align-items: center;" onclick="toggleInterviewAccordion(${idx})">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <span class="badge badge-primary" style="font-size: 0.75rem;">${escapeHtml(q.category || 'Technical')}</span>
                    <span style="font-weight: 700; font-size: 0.95rem; color: var(--text-primary);">Q${idx + 1}: ${escapeHtml(q.question)}</span>
                </div>
                <i class="fa-solid fa-chevron-down text-muted" id="prepChevron${idx}"></i>
            </div>
            <div id="prepBody${idx}" style="display: ${idx === 0 ? 'block' : 'none'}; padding: 0 1.25rem 1.25rem 1.25rem; border-top: 1px solid rgba(255,255,255,0.05); background: rgba(0,0,0,0.2);">
                <div style="font-size: 0.82rem; font-weight: 700; color: var(--primary); margin-top: 0.75rem; margin-bottom: 0.3rem;">
                    <i class="fa-solid fa-lightbulb"></i> Recommended Candidate Strategy Hint:
                </div>
                <p style="font-size: 0.88rem; color: var(--text-secondary); line-height: 1.6; margin: 0;">
                    ${escapeHtml(q.answer_hint)}
                </p>
            </div>
        `;
        container.appendChild(card);
    });

    const regenBtn = document.getElementById('regenInterviewBtn');
    if (regenBtn) {
        regenBtn.onclick = async () => {
            showToast('Generating fresh AI interview questions...', 'info');
            try {
                const stored = JSON.parse(sessionStorage.getItem('current_analysis') || '{}');
                const res = await fetch('/api/generate-interview-prep/', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ analysis_id: stored.id || 999 })
                });
                const data = await res.json();
                if (data.interview_prep) {
                    renderInterviewPrep(data.interview_prep);
                    showToast('Updated interview questions!', 'success');
                }
            } catch (e) {
                showToast('Failed to refresh questions.', 'warning');
            }
        };
    }
}

function toggleInterviewAccordion(idx) {
    const body = document.getElementById(`prepBody${idx}`);
    const chevron = document.getElementById(`prepChevron${idx}`);
    if (body) {
        const isOpen = body.style.display === 'block';
        body.style.display = isOpen ? 'none' : 'block';
        if (chevron) {
            chevron.className = isOpen ? 'fa-solid fa-chevron-down text-muted' : 'fa-solid fa-chevron-up text-primary';
        }
    }
}

/* Chart.js Setup */
function initCharts(data) {
    // Chart Theme Variables
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const textColor = isDark ? '#cbd5e1' : '#475569';
    const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';

    Chart.defaults.color = textColor;
    Chart.defaults.font.family = "'Plus Jakarta Sans', sans-serif";

    // 1. Score Breakdown Doughnut Chart
    const doughnutCtx = document.getElementById('doughnutChartCanvas');
    if (doughnutCtx) {
        if (charts.doughnut) charts.doughnut.destroy();
        charts.doughnut = new Chart(doughnutCtx, {
            type: 'doughnut',
            data: {
                labels: ['ATS Score', 'Content Quality', 'Skills', 'Experience', 'Formatting', 'Contact Info'],
                datasets: [{
                    data: [
                        data.ats_score || 0,
                        data.content_score || 0,
                        data.skills_score || 0,
                        data.experience_score || 0,
                        data.formatting_score || 0,
                        data.contact_score || 0
                    ],
                    backgroundColor: ['#6366f1', '#10b981', '#f59e0b', '#3b82f6', '#8b5cf6', '#ec4899'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true } }
                },
                cutout: '72%'
            }
        });
    }

    // 2. Skill Category Distribution Bar Chart
    const skillCtx = document.getElementById('skillBarChartCanvas');
    if (skillCtx) {
        if (charts.skillBar) charts.skillBar.destroy();
        const counts = data.extracted_skills?.category_counts || {};
        charts.skillBar = new Chart(skillCtx, {
            type: 'bar',
            data: {
                labels: Object.keys(counts),
                datasets: [{
                    label: 'Skills Count',
                    data: Object.values(counts),
                    backgroundColor: 'rgba(99, 102, 241, 0.8)',
                    borderRadius: 8,
                    hoverBackgroundColor: '#4f46e5'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false } },
                    y: { grid: { color: gridColor }, beginAtZero: true }
                }
            }
        });
    }

    // 3. Multi-Role Radar Chart
    renderMultiRoleChart(data.multi_role_scores || {});
}

/* Skills Badges */
function renderSkillBadges(data) {
    const container = document.getElementById('extractedSkillsContainer');
    const missingContainer = document.getElementById('missingSkillsContainer');
    if (!container) return;

    container.innerHTML = '';
    const categories = data.extracted_skills?.categories || {};
    
    let totalAdded = 0;
    for (const [cat, skills] of Object.entries(categories)) {
        skills.forEach(skill => {
            const chip = document.createElement('span');
            chip.className = 'skill-chip';
            chip.innerHTML = `<i class="fa-solid fa-check text-success"></i> ${skill}`;
            container.appendChild(chip);
            totalAdded++;
        });
    }

    if (totalAdded === 0) {
        container.innerHTML = '<span class="text-muted">No structured skills detected.</span>';
    }

    // Missing skills
    if (missingContainer) {
        missingContainer.innerHTML = '';
        const missing = data.job_match_analysis?.missing_skills || [];
        if (missing.length > 0) {
            missing.forEach(skill => {
                const chip = document.createElement('span');
                chip.className = 'skill-chip missing';
                chip.innerHTML = `<i class="fa-solid fa-plus"></i> ${skill}`;
                missingContainer.appendChild(chip);
            });
        } else {
            missingContainer.innerHTML = '<span class="text-muted">No missing skills detected against Job Description!</span>';
        }
    }
}

/* Health Checklist */
function renderHealthChecklist(list) {
    const container = document.getElementById('healthGrid');
    if (!container) return;
    container.innerHTML = '';

    list.forEach(item => {
        const div = document.createElement('div');
        div.className = 'health-item';
        div.innerHTML = `
            <span>${item.name}</span>
            <div class="health-indicator ${item.status}"></div>
        `;
        container.appendChild(div);
    });
}

/* ATS Issues */
function renderAtsIssues(issues) {
    const container = document.getElementById('atsIssueList');
    if (!container) return;
    container.innerHTML = '';

    if (issues.length === 0) {
        container.innerHTML = '<div class="card"><p class="text-muted">No ATS formatting issues found!</p></div>';
        return;
    }

    issues.forEach(issue => {
        const div = document.createElement('div');
        div.className = 'issue-card';
        
        let badgeClass = 'badge-info';
        if (issue.severity === 'Critical') badgeClass = 'badge-danger';
        if (issue.severity === 'High') badgeClass = 'badge-warning';
        if (issue.severity === 'Good') badgeClass = 'badge-success';

        div.innerHTML = `
            <div class="issue-header">
                <span class="issue-title">${issue.title}</span>
                <span class="badge ${badgeClass}">${issue.severity}</span>
            </div>
            <div class="issue-explanation">${issue.explanation}</div>
            <div class="issue-recommendation"><i class="fa-solid fa-lightbulb"></i> <b>Recommendation:</b> ${issue.recommendation}</div>
        `;
        container.appendChild(div);
    });
}

/* Action Verbs */
function renderActionVerbs(verbData) {
    const weakContainer = document.getElementById('weakVerbsContainer');
    const strongContainer = document.getElementById('strongVerbsContainer');

    if (weakContainer) {
        weakContainer.innerHTML = '';
        const weakList = verbData.weak_verbs || [];
        if (weakList.length > 0) {
            weakList.forEach(item => {
                const div = document.createElement('div');
                div.className = 'issue-recommendation';
                div.style.marginBottom = '8px';
                div.innerHTML = `Found weak verb <b>"${item.verb}"</b> (${item.count}x). Try replacing with: <i>${item.suggestion}</i>`;
                weakContainer.appendChild(div);
            });
        } else {
            weakContainer.innerHTML = '<span class="badge badge-success">✓ No weak verbs detected! Great action-oriented writing.</span>';
        }
    }

    if (strongContainer) {
        strongContainer.innerHTML = '';
        const strongList = verbData.strong_verbs || [];
        strongList.forEach(v => {
            const chip = document.createElement('span');
            chip.className = 'skill-chip';
            chip.innerHTML = `<i class="fa-solid fa-bolt text-warning"></i> ${v}`;
            strongContainer.appendChild(chip);
        });
    }
}

/* Summaries */
function renderSummaries(summaries) {
    const container = document.getElementById('summarySuggestionsContainer');
    if (!container) return;
    container.innerHTML = '';

    summaries.forEach((text, idx) => {
        const card = document.createElement('div');
        card.className = 'card';
        card.style.marginBottom = '1rem';
        card.innerHTML = `
            <div class="card-header">
                <span class="card-title" style="font-size:0.95rem;">Option ${idx + 1}</span>
                <button class="btn btn-sm btn-secondary copy-summary-btn" data-text="${escapeHtml(text)}">
                    <i class="fa-regular fa-copy"></i> Copy
                </button>
            </div>
            <p style="font-size:0.9rem; line-height:1.6; color:var(--text-secondary);">${text}</p>
        `;
        container.appendChild(card);
    });

    document.querySelectorAll('.copy-summary-btn').forEach(btn => {
        btn.onclick = (e) => {
            const txt = e.currentTarget.getAttribute('data-text');
            navigator.clipboard.writeText(txt);
            showToast('Summary copied to clipboard!', 'success');
        };
    });
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
