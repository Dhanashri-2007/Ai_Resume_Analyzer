/**
 * ResumeAI - Drag & Drop Resume Upload Controller
 */

document.addEventListener('DOMContentLoaded', () => {
    initUploadController();
});

function initUploadController() {
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');
    const filePreview = document.getElementById('filePreview');
    const fileNameSpan = document.getElementById('fileName');
    const fileSizeSpan = document.getElementById('fileSize');
    const removeFileBtn = document.getElementById('removeFileBtn');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const jobDescriptionInput = document.getElementById('jobDescriptionInput');
    const clearJdBtn = document.getElementById('clearJdBtn');
    const progressContainer = document.getElementById('progressContainer');
    const progressBarFill = document.getElementById('progressBarFill');
    const progressStatusText = document.getElementById('progressStatusText');

    let selectedFile = null;

    if (!dropzone || !fileInput) return;

    // Click dropzone to open file dialog
    dropzone.addEventListener('click', (e) => {
        if (e.target !== removeFileBtn && !removeFileBtn.contains(e.target)) {
            fileInput.click();
        }
    });

    // File input change
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileSelection(e.target.files[0]);
        }
    });

    // Drag and Drop Events
    ['dragenter', 'dragover'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropzone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.remove('dragover');
        }, false);
    });

    dropzone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length > 0) {
            handleFileSelection(files[0]);
        }
    });

    // Handle selected file validation
    function handleFileSelection(file) {
        const validTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/msword', 'text/plain'];
        const ext = file.name.split('.').pop().toLowerCase();
        
        if (!['pdf', 'docx', 'doc', 'txt'].includes(ext)) {
            showToast('Please upload a valid PDF, DOCX, or TXT file.', 'danger');
            return;
        }

        if (file.size > 10 * 1024 * 1024) { // 10MB
            showToast('File size exceeds the 10 MB limit.', 'warning');
            return;
        }

        selectedFile = file;
        fileNameSpan.innerText = file.name;
        fileSizeSpan.innerText = formatBytes(file.size);

        filePreview.style.display = 'flex';
        dropzone.querySelector('.dropzone-content').style.display = 'none';
        analyzeBtn.disabled = false;
        showToast('Resume selected successfully!', 'success');
    }

    // Remove File
    removeFileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        selectedFile = null;
        fileInput.value = '';
        filePreview.style.display = 'none';
        dropzone.querySelector('.dropzone-content').style.display = 'block';
        analyzeBtn.disabled = true;
    });

    // Clear JD
    if (clearJdBtn && jobDescriptionInput) {
        clearJdBtn.addEventListener('click', () => {
            jobDescriptionInput.value = '';
            showToast('Job Description cleared.', 'info');
        });
    }

    // Analyze Button Submit
    analyzeBtn.addEventListener('click', async () => {
        if (!selectedFile) {
            showToast('Please select a resume file first.', 'warning');
            return;
        }

        const formData = new FormData();
        formData.append('file', selectedFile);
        if (jobDescriptionInput && jobDescriptionInput.value.trim()) {
            formData.append('job_description', jobDescriptionInput.value.trim());
        }

        // Show Loading Progress
        progressContainer.style.display = 'block';
        analyzeBtn.disabled = true;
        analyzeBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Analyzing Resume...`;

        simulateProgress();

        try {
            const response = await fetch('/api/analyze-resume/', {
                method: 'POST',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: formData
            });

            const data = await response.json();

            if (response.ok) {
                progressBarFill.style.width = '100%';
                progressStatusText.innerText = 'Analysis complete! Rendering dashboard...';
                
                // Store analysis data in sessionStorage
                sessionStorage.setItem('current_analysis', JSON.stringify(data));
                
                setTimeout(() => {
                    window.location.href = `/dashboard/${data.id}/`;
                }, 600);
            } else {
                throw new Error(data.error || 'Failed to analyze resume.');
            }
        } catch (err) {
            progressContainer.style.display = 'none';
            analyzeBtn.disabled = false;
            analyzeBtn.innerHTML = `<i class="fa-solid fa-wand-magic-sparkles"></i> Analyze Resume`;
            showToast(err.message, 'danger');
        }
    });

    function simulateProgress() {
        let progress = 10;
        progressBarFill.style.width = '10%';
        const interval = setInterval(() => {
            progress += Math.floor(Math.random() * 15) + 5;
            if (progress >= 85) {
                progress = 85;
                clearInterval(interval);
            }
            progressBarFill.style.width = `${progress}%`;
            if (progress < 40) progressStatusText.innerText = 'Extracting resume text & metadata...';
            else if (progress < 70) progressStatusText.innerText = 'Evaluating ATS score & technical skills...';
            else progressStatusText.innerText = 'Matching job requirements & generating insights...';
        }, 300);
    }
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
