/**
 * ResumeAI - Interactive Bullet Point Improver Tool
 */

document.addEventListener('DOMContentLoaded', () => {
    initBulletImprover();
});

function initBulletImprover() {
    const inputEl = document.getElementById('bulletInput');
    const improveBtn = document.getElementById('improveBulletBtn');
    const outputContainer = document.getElementById('bulletOutputBox');
    const improvedTextEl = document.getElementById('improvedBulletText');
    const whyBetterEl = document.getElementById('bulletWhyBetter');
    const copyBulletBtn = document.getElementById('copyBulletBtn');

    if (!inputEl || !improveBtn) return;

    improveBtn.addEventListener('click', async () => {
        const text = inputEl.value.trim();
        if (!text) {
            showToast('Please enter a bullet point to improve.', 'warning');
            return;
        }

        improveBtn.disabled = true;
        improveBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Improving...`;

        try {
            const response = await fetch('/api/improve-bullet/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({ bullet: text })
            });

            const data = await response.json();

            if (response.ok) {
                if (outputContainer) outputContainer.style.display = 'block';
                if (improvedTextEl) improvedTextEl.innerText = data.improved;
                if (whyBetterEl) whyBetterEl.innerHTML = `<b>Why it's better:</b> ${data.why_better}`;
                showToast('Bullet point improved successfully!', 'success');
            } else {
                throw new Error(data.error || 'Failed to improve bullet point.');
            }
        } catch (err) {
            showToast(err.message, 'danger');
        } finally {
            improveBtn.disabled = false;
            improveBtn.innerHTML = `<i class="fa-solid fa-wand-magic-sparkles"></i> Improve Bullet`;
        }
    });

    if (copyBulletBtn) {
        copyBulletBtn.addEventListener('click', () => {
            const txt = improvedTextEl.innerText;
            if (txt) {
                navigator.clipboard.writeText(txt);
                showToast('Improved bullet point copied!', 'success');
            }
        });
    }
}
