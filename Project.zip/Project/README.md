# AI Resume Analyzer 🚀

A production-quality, competition-ready web application designed to evaluate resume quality, audit ATS (Applicant Tracking System) compatibility, extract technical skills across 300+ categories, perform job description skill gap analysis, refine weak bullet points, and generate downloadable diagnostic PDF reports.

Built with **Python 3, Django, Vanilla JavaScript, CSS3, HTML5, Chart.js, and PyMuPDF**. Features a hybrid AI service layer that runs 100% offline out-of-the-box using local heuristic rules, with optional integration for Google Gemini / OpenAI via `.env`.

---

## 🌟 Key Features

1. **Intelligent Text & Contact Extraction**: Parses `.pdf`, `.docx`, and `.txt` files to extract Name, Email, Phone, Location, LinkedIn, GitHub, Portfolio links, and standard resume sections (Summary, Skills, Experience, Education, Projects, Achievements).
2. **Weighted AI Resume Score (0–100)**: Evaluates resumes based on configurable criteria:
   - ATS Compatibility (25%)
   - Content Quality & Metrics (20%)
   - Technical Skills Strength (15%)
   - Work Experience (15%)
   - Education (10%)
   - Formatting & Structure (10%)
   - Contact Info & Links (5%)
3. **ATS Diagnostic Engine**: Categorizes issues by severity (`Critical`, `High`, `Medium`, `Good`) with actionable recommendations.
4. **300+ Skill Extraction & Gap Analysis**: Categorizes technical skills into *Programming Languages, Web Tech, Databases, Cloud, DevOps, and Data Science/AI*. Highlights matched vs missing skills against job descriptions.
5. **Interactive Bullet Point Improver**: Transforms passive bullet points (e.g., *"Worked on backend API"*) into metric-driven STAR format bullet points with an explanation of why the rewrite is superior.
6. **AI Professional Summary Generator**: Provides 3 tailored summary options with one-click clipboard copy buttons.
7. **Chart.js Visualizations**: Animated score weight doughnut chart, skill category bar chart, and job match radar chart.
8. **Downloadable PDF Diagnostic Report**: Server-side ReportLab PDF generator produces professional downloadable reports.
9. **Competition "Try Demo" Mode**: One-click demo loads a complete dataset instantly without requiring file uploads or external API keys.
10. **Modern SaaS UI/UX**: Dynamic Glassmorphism cards, animated score ring meter, dark/light mode toggle, toast notifications, and responsive mobile navigation.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, Vanilla CSS3 (Custom Design System, Glassmorphism, CSS Variables), Vanilla JavaScript (ES6+), [Chart.js](https://www.chartjs.org/), [Font Awesome 6](https://fontawesome.com/)
- **Backend**: Python 3.11, [Django 5.2](https://www.djangoproject.com/), [Django REST Framework](https://www.django-rest-framework.org/)
- **Text Extraction**: `PyMuPDF` (`pymupdf`), `python-docx`
- **PDF Report Generation**: `ReportLab`
- **Database**: SQLite3 (Development) / PostgreSQL Ready
- **AI Integration**: Custom Heuristic Rule Engine (Local Fallback) + `google-genai` (Optional Gemini API)

---

## 📁 Directory Structure

```
Project/
│
├── manage.py                # Django CLI management script
├── requirements.txt         # Project dependencies
├── .env.example             # Environment configuration template
├── .env                     # Local environment settings
├── README.md                # Documentation & quickstart guide
├── db.sqlite3               # SQLite database file
│
├── config/                  # Django project configuration
│   ├── settings.py          # Apps, static/media, middleware settings
│   ├── urls.py              # Root URL router
│   ├── wsgi.py              # WSGI entrypoint
│   └── asgi.py              # ASGI entrypoint
│
├── analyzer/                # Core AI Resume Analyzer app
│   ├── models.py            # ResumeAnalysis database model
│   ├── views.py             # Page rendering views & REST API endpoints
│   ├── urls.py              # App API & page routes
│   ├── serializers.py       # DRF serializers & input validation
│   ├── mock_data.py         # Competition demo dataset
│   ├── tests.py             # Unit test suite
│   └── services/            # Modular business logic services
│       ├── extractor.py     # PDF/DOCX/TXT text & contact parser
│       ├── skill_engine.py  # 300+ skill dictionary & categorizer
│       ├── scoring_engine.py# ATS scoring & verb analyzer
│       ├── job_matcher.py   # Skill gap & job description matcher
│       ├── ai_service.py    # Dual AI layer (Gemini API + Local Fallback)
│       └── report_service.py# ReportLab PDF report builder
│
├── templates/               # HTML5 templates
│   ├── base.html            # Layout with navbar, theme toggle & footer
│   ├── index.html           # Landing page with hero, stats & features
│   ├── upload.html          # Drag & drop upload & JD input page
│   └── dashboard.html       # Analytics dashboard & Chart.js widgets
│
└── static/                  # Static assets
    ├── css/
    │   ├── main.css         # Theme variables, typography & layout
    │   ├── components.css   # Cards, badges, progress bars & dropzone
    │   └── dashboard.css    # Analytics widgets, score ring & grids
    └── js/
        ├── app.js           # Theme toggle, toast system & counters
        ├── upload.js        # File validation, drag-and-drop & API upload
        ├── dashboard.js     # Chart.js initialization & dynamic rendering
        └── bullet_improver.js# Bullet improver tool controller
```

---

## 🚀 Installation & Setup (Windows)

Follow these simple steps to set up and run the project locally on Windows:

### Step 1: Open PowerShell or Command Prompt
Navigate to your desired workspace folder:
```powershell
cd c:\Users\Roshan_Nikam\Desktop\Project
```

### Step 2: Create & Activate a Virtual Environment (Optional but Recommended)
```powershell
python -m venv venv
.\venv\Scripts\Activate
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Configure Environment Variables
Copy `.env.example` to create `.env`:
```powershell
copy .env.example .env
```
*(Optionally open `.env` in Notepad to add your Google Gemini or OpenAI API key).*

### Step 5: Apply Database Migrations
```powershell
python manage.py makemigrations analyzer
python manage.py migrate
```

### Step 6: Run Backend Unit Tests
Verify that all 10 tests pass:
```powershell
python manage.py test analyzer
```

### Step 7: Start the Django Server
```powershell
python manage.py runserver 8000
```

### Step 8: Open the Web Application
Open your web browser and visit:
```
http://127.0.0.1:8000/
```

---

## 🔑 AI API Configuration (Optional)

By default, the application runs **100% offline** using an intelligent local rule-based analysis engine. 

To enable external AI capabilities using Google Gemini:
1. Obtain an API key from [Google AI Studio](https://aistudio.google.com/).
2. Open `.env` and update:
   ```env
   AI_PROVIDER=gemini
   AI_API_KEY=your_actual_gemini_api_key_here
   ```
3. Restart the Django server.

If the API key is invalid or network connection drops, the system **automatically falls back to the local engine** without throwing server errors.

---

## 🏆 Competition Presentation & Demo Mode

To demonstrate the application during a presentation or hackathon judging without uploading files:
1. Click the **"Try Demo"** button on the top navbar or landing page hero section.
2. The platform will instantly load the realistic pre-configured dataset for **Alex Morgan (Senior Full Stack Engineer)**.
3. Show the animated circular score gauge, Chart.js charts, skill badges, ATS diagnostic warnings, AI professional summary cards, and the interactive Bullet Point Improver tool.
4. Click **"Download PDF Report"** to show instant server-side PDF generation.

---

## 🔍 Troubleshooting

- **`fitz` deprecation warning**: PyMuPDF has updated its package namespace to `pymupdf`. The code explicitly uses `import pymupdf`.
- **File size upload error**: Maximum upload size is configured to 10 MB in `config/settings.py` via `DATA_UPLOAD_MAX_MEMORY_SIZE`.
- **Port 8000 in use**: Run `python manage.py runserver 8080` to use port 8080 instead.
- **CSRF Token errors**: Ensure JavaScript files pass `X-CSRFToken` from `getCookie('csrftoken')`.

---

## 📜 License & Disclaimer

ResumeAI is designed for educational, portfolio, and competition demonstration purposes. Results provided are automated diagnostic estimates based on current resume parsing heuristics and best practices.
