# Implementation Plan - AI Resume Analyzer

A production-quality, competition-ready AI Resume Analyzer built with Django, Vanilla JavaScript, CSS3, and HTML5. The application extracts content from resumes (PDF, DOCX, TXT), evaluates ATS compatibility, categorizes skills, detects skill gaps against job descriptions, provides actionable AI bullet & summary suggestions, and displays interactive Chart.js analytics on a sleek modern dashboard.

## Proposed Architecture

```
Project/
│
├── manage.py
├── requirements.txt
├── .env.example
├── README.md
│
├── config/
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
│
├── analyzer/
│   ├── models.py              # ResumeAnalysis model
│   ├── views.py               # Page views & JSON API endpoints
│   ├── urls.py                # App routing
│   ├── serializers.py         # DRF serializers / data validation
│   ├── services/              # Modular business logic
│   │   ├── extractor.py       # PDF/DOCX/TXT text extraction & parsing
│   │   ├── skill_engine.py    # Skill dictionary & keyword extraction
│   │   ├── scoring_engine.py  # ATS & weighted score calculation
│   │   ├── job_matcher.py     # Skill gap & job description comparison
│   │   ├── ai_service.py      # Gemini/OpenAI wrapper with local rule fallback
│   │   └── report_service.py  # ReportLab PDF report generation
│   ├── tests.py               # Unit and integration tests
│   └── mock_data.py           # Competition demo dataset
│
├── templates/
│   ├── base.html              # Base layout with navbar, theme toggle & footer
│   ├── index.html             # Landing page with hero, stats, features, demo CTA
│   ├── upload.html            # Drag-and-drop file upload & JD input page
│   └── dashboard.html         # Full analytics dashboard with charts & tools
│
└── static/
    ├── css/
    │   ├── main.css           # Glassmorphism design system & dark/light theme variables
    │   ├── components.css     # Buttons, badges, cards, progress bars, toast, modals
    │   └── dashboard.css      # Grid layout & custom dashboard widget styles
    ├── js/
    │   ├── app.js             # Navigation, theme toggle, dynamic counters
    │   ├── upload.js          # Drag-and-drop, validation, progress, file handling
    │   ├── dashboard.js       # Chart.js initialization & dynamic content rendering
    │   └── bullet_improver.js # Interactive bullet improver & summary generator
    └── images/
        └── favicon.ico
```

---

## User Review Required

> [!IMPORTANT]
> **No External API Key Required to Test**: The system will include a robust local rule-based analysis engine so it runs 100% offline out-of-the-box. Google Gemini or OpenAI can be optionally enabled by setting `AI_API_KEY` in `.env`.
> 
> **Demo Mode Included**: A "Try Demo" mode allows instant competition presentations without uploading files or querying external APIs.

---

## Proposed Changes

### 1. Project Dependencies & Configuration

#### [NEW] [requirements.txt](file:///c:/Users/Roshan_Nikam/Desktop/Project/requirements.txt)
- `Django>=5.0`
- `djangorestframework>=3.14`
- `PyMuPDF>=1.23` (fitz for PDF text extraction)
- `python-docx>=1.1` (DOCX extraction)
- `python-dotenv>=1.0` (Environment configuration)
- `reportlab>=4.1` (PDF report generation)
- `google-genai>=0.1` (Optional Gemini AI integration)

#### [NEW] [.env.example](file:///c:/Users/Roshan_Nikam/Desktop/Project/.env.example)
- Environment variable template for Django secret key, debug mode, and AI API credentials.

#### [NEW] [config/settings.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/config/settings.py)
- Configured for static files, media uploads, templates, DRF, and SQLite DB (prepared for PostgreSQL migration).

---

### 2. Django Backend Application (`analyzer`)

#### [NEW] [analyzer/models.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/models.py)
- `ResumeAnalysis` model storing resume filename, upload timestamp, extracted text, metadata, calculated scores (overall, ATS, skills, content, experience, formatting, contact), extracted skills, missing skills, ATS recommendations, and job description text.

#### [NEW] [analyzer/services/extractor.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/services/extractor.py)
- Text extraction modules for `.pdf`, `.docx`, and `.txt`.
- Smart parsing regex for Contact Info (Email, Phone, LinkedIn, GitHub, Portfolio, Location), Name detection, and Section segmentation (Summary, Skills, Experience, Education, Projects, Certifications, Achievements).

#### [NEW] [analyzer/services/skill_engine.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/services/skill_engine.py)
- Dictionary of 300+ skills grouped by category:
  - Programming Languages
  - Web Technologies
  - Databases
  - Cloud Services
  - DevOps & Tools
  - Data Science & AI
- Context-aware keyword matching engine.

#### [NEW] [analyzer/services/scoring_engine.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/services/scoring_engine.py)
- Weighted ATS formula:
  - ATS Compatibility (25%)
  - Content Quality (20%)
  - Skills (15%)
  - Experience (15%)
  - Education (10%)
  - Formatting & Structure (10%)
  - Contact/Links (5%)
- Issue detector with severity classification (`Critical`, `High`, `Medium`, `Low`, `Good`).
- Weak action verb detector with replacement recommendations (`worked` -> `developed`, `helped` -> `spearheaded`).

#### [NEW] [analyzer/services/job_matcher.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/services/job_matcher.py)
- Compares resume text & skills against job description requirements.
- Calculates Job Match Score (0–100%), extracts matched keywords, missing keywords, and contextual improvement recommendations.

#### [NEW] [analyzer/services/ai_service.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/services/ai_service.py)
- Dual-mode architecture:
  1. AI API Mode: Calls Google Gemini API if `AI_API_KEY` is present.
  2. Fallback Mode: High-precision local heuristic rules generator if API key is absent or network fails.
- Features: Summary Generator (3 variants) and Bullet Point Improver.

#### [NEW] [analyzer/services/report_service.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/services/report_service.py)
- Generates a PDF summary report using ReportLab.

#### [NEW] [analyzer/views.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/views.py)
- Endpoints:
  - `POST /api/analyze-resume/`
  - `POST /api/job-match/`
  - `POST /api/improve-bullet/`
  - `POST /api/improve-summary/`
  - `GET /api/demo/`
  - `GET /api/download-report/<int:pk>/`

#### [NEW] [analyzer/tests.py](file:///c:/Users/Roshan_Nikam/Desktop/Project/analyzer/tests.py)
- Unit tests covering extraction, scoring, skill categorizer, job matcher, and API views.

---

### 3. Frontend Interface & Design System

#### [NEW] [static/css/main.css](file:///c:/Users/Roshan_Nikam/Desktop/Project/static/css/main.css)
- CSS Variables for Light/Dark themes, glassmorphism cards, animated background gradients, responsive grid layouts, custom typography.

#### [NEW] [static/css/dashboard.css](file:///c:/Users/Roshan_Nikam/Desktop/Project/static/css/dashboard.css)
- Circular progress indicators, Chart.js container styling, keyword badges, accordion lists for ATS suggestions.

#### [NEW] [static/js/app.js](file:///c:/Users/Roshan_Nikam/Desktop/Project/static/js/app.js)
- Dark mode toggle state management, smooth scrolling, toast notifications, animated counter effects.

#### [NEW] [static/js/upload.js](file:///c:/Users/Roshan_Nikam/Desktop/Project/static/js/upload.js)
- Drag-and-drop area listeners, client-side file size & extension validation, upload progress spinner, API integration.

#### [NEW] [static/js/dashboard.js](file:///c:/Users/Roshan_Nikam/Desktop/Project/static/js/dashboard.js)
- Chart.js chart setup (Score Doughnut, Skill Category Bar, Job Match Radar, Keyword Match Horizontal Bar), SVG animated circular meter, dynamic data population.

#### [NEW] [templates/index.html](file:///c:/Users/Roshan_Nikam/Desktop/Project/templates/index.html)
- Modern landing page with interactive hero, statistics counters, feature breakdown, how-it-works timeline, demo button.

#### [NEW] [templates/dashboard.html](file:///c:/Users/Roshan_Nikam/Desktop/Project/templates/dashboard.html)
- Main analysis dashboard containing score gauges, breakdown cards, health checklist, chart widgets, AI summary suggestions, interactive bullet point improver, and PDF report download.

---

## Verification Plan

### Automated Tests
1. Run Django test suite:
   ```powershell
   python manage.py test analyzer
   ```
2. Verify all tests for text extraction, skill categorizer, scoring engine, job matching, and REST API endpoints pass with 0 errors.

### Manual & UI Verification
1. Start the Django dev server:
   ```powershell
   python manage.py runserver
   ```
2. Launch browser subagent to interact with the running site:
   - Test Landing Page visuals, counters, navigation, and theme toggle.
   - Test "Try Demo" mode to verify instant populated dashboard visualization with Chart.js charts.
   - Test uploading sample PDF, DOCX, and TXT resumes with and without a Job Description.
   - Verify ATS score calculation, skill breakdown badges, weak action verb suggestions, AI bullet improver tool, and PDF report generation.
